//Simple MFC Example - Basic Message Map Analysis
//Demonstrates basic usage of MFC analysis techniques
//@author MFC Analysis Scripts
//@category MFC.Examples
//@keybinding 
//@menupath Tools.MFC.Examples.Simple MFC Analysis
//@toolbar 

import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.*;
import ghidra.program.model.data.*;
import ghidra.program.model.listing.*;
import ghidra.program.model.mem.*;
import ghidra.program.model.symbol.*;
import java.util.*;

public class SimpleMFCExample extends GhidraScript {
    
    @Override
    public void run() throws Exception {
        println("=== Simple MFC Analysis Example ===");
        println("This script demonstrates basic MFC analysis techniques.");
        println();
        
        // Step 1: Look for MFC indicators
        checkMFCIndicators();
        
        // Step 2: Find message map symbols
        findMessageMapSymbols();
        
        // Step 3: Analyze a simple message map
        analyzeSimpleMessageMap();
        
        // Step 4: Show results
        showResults();
        
        println("\\nExample analysis completed!");
    }
    
    /**
     * Check for basic MFC indicators in the program
     */
    private void checkMFCIndicators() {
        println("--- Checking for MFC Indicators ---");
        
        // Look for common MFC strings
        String[] mfcStrings = {"CWnd", "CDialog", "GetMessageMap", "AFX_"};
        boolean foundMFC = false;
        
        for (String mfcString : mfcStrings) {
            Address found = findString(mfcString);
            if (found != null) {
                println("Found MFC indicator: '" + mfcString + "' at " + found);
                foundMFC = true;
            }
        }
        
        if (!foundMFC) {
            println("No obvious MFC indicators found - may not be an MFC application");
        }
        
        println();
    }
    
    /**
     * Find a string in the program
     */
    private Address findString(String searchString) {
        try {
            Memory memory = currentProgram.getMemory();
            AddressSetView searchSet = memory.getLoadedAndInitializedAddressSet();
            return memory.findBytes(searchSet.getMinAddress(), searchString.getBytes(), 
                                  null, true, monitor);
        } catch (Exception e) {
            return null;
        }
    }
    
    /**
     * Find message map related symbols
     */
    private void findMessageMapSymbols() {
        println("--- Looking for Message Map Symbols ---");
        
        SymbolTable symbolTable = currentProgram.getSymbolTable();
        SymbolIterator symbols = symbolTable.getAllSymbols(true);
        
        int messageMapCount = 0;
        while (symbols.hasNext()) {
            Symbol symbol = symbols.next();
            String name = symbol.getName();
            
            if (name.toLowerCase().contains("messagemap") || 
                name.toLowerCase().contains("getmessagemap")) {
                println("Found message map symbol: " + name + " at " + symbol.getAddress());
                messageMapCount++;
            }
        }
        
        if (messageMapCount == 0) {
            println("No message map symbols found - looking for patterns...");
            lookForMessageMapPatterns();
        } else {
            println("Found " + messageMapCount + " message map related symbols");
        }
        
        println();
    }
    
    /**
     * Look for message map patterns in memory
     */
    private void lookForMessageMapPatterns() {
        try {
            // Look for potential AFX_MSGMAP_ENTRY patterns
            // This is a simplified search - real implementation would be more thorough
            
            Memory memory = currentProgram.getMemory();
            
            // Search for common message IDs like WM_COMMAND (0x0111)
            byte[] wmCommandBytes = {0x11, 0x01, 0x00, 0x00}; // WM_COMMAND in little-endian
            
            AddressSetView searchSet = memory.getLoadedAndInitializedAddressSet();
            Address found = memory.findBytes(searchSet.getMinAddress(), wmCommandBytes, 
                                           null, true, monitor);
            
            if (found != null) {
                println("Found potential WM_COMMAND entry at " + found);
                analyzeMessageMapEntry(found);
            } else {
                println("No obvious message map patterns found");
            }
            
        } catch (Exception e) {
            println("Error searching for patterns: " + e.getMessage());
        }
    }
    
    /**
     * Analyze a potential message map entry
     */
    private void analyzeMessageMapEntry(Address addr) {
        try {
            Memory memory = currentProgram.getMemory();
            
            // Read potential AFX_MSGMAP_ENTRY structure
            long nMessage = memory.getInt(addr) & 0xFFFFFFFFL;
            long nCode = memory.getInt(addr.add(4)) & 0xFFFFFFFFL;
            long nID = memory.getInt(addr.add(8)) & 0xFFFFFFFFL;
            long nLastID = memory.getInt(addr.add(12)) & 0xFFFFFFFFL;
            
            println("Potential message map entry:");
            println("  Message: 0x" + Long.toHexString(nMessage) + 
                   (nMessage == 0x0111 ? " (WM_COMMAND)" : ""));
            println("  Code: " + nCode);
            println("  ID: " + nID);
            println("  LastID: " + nLastID);
            
            // Try to read function pointer
            int ptrSize = currentProgram.getDefaultPointerSize();
            Address pfnAddr;
            
            if (ptrSize == 8) {
                long pfnValue = memory.getLong(addr.add(24));
                pfnAddr = pfnValue != 0 ? 
                    currentProgram.getAddressFactory().getDefaultAddressSpace().getAddress(pfnValue) : null;
            } else {
                long pfnValue = memory.getInt(addr.add(20)) & 0xFFFFFFFFL;
                pfnAddr = pfnValue != 0 ? 
                    currentProgram.getAddressFactory().getDefaultAddressSpace().getAddress(pfnValue) : null;
            }
            
            if (pfnAddr != null) {
                println("  Handler function: " + pfnAddr);
                
                // Check if there's a function at this address
                Function func = currentProgram.getFunctionManager().getFunctionAt(pfnAddr);
                if (func != null) {
                    println("  Function name: " + func.getName());
                } else {
                    println("  No function defined at handler address");
                }
            }
            
        } catch (Exception e) {
            println("Error analyzing message map entry: " + e.getMessage());
        }
    }
    
    /**
     * Analyze a simple message map structure
     */
    private void analyzeSimpleMessageMap() {
        println("--- Analyzing Message Map Structure ---");
        
        // This is a simplified example - in practice, you'd use the full scanner
        // Look for GetMessageMap functions
        FunctionManager funcMgr = currentProgram.getFunctionManager();
        FunctionIterator functions = funcMgr.getFunctions(true);
        
        while (functions.hasNext()) {
            Function func = functions.next();
            String funcName = func.getName();
            
            if (funcName.toLowerCase().contains("getmessagemap")) {
                println("Analyzing GetMessageMap function: " + funcName);
                analyzeGetMessageMapFunction(func);
                break; // Just analyze the first one for this example
            }
        }
        
        println();
    }
    
    /**
     * Analyze a GetMessageMap function
     */
    private void analyzeGetMessageMapFunction(Function func) {
        try {
            // Look for references to message map data
            ReferenceManager refMgr = currentProgram.getReferenceManager();
            ReferenceIterator refs = refMgr.getReferencesFrom(func.getBody(), true);
            
            while (refs.hasNext()) {
                Reference ref = refs.next();
                Address toAddr = ref.getToAddress();
                
                // Check if this points to a data structure
                Data data = currentProgram.getListing().getDataAt(toAddr);
                if (data != null) {
                    println("  References data at " + toAddr + ": " + data.getDataType().getName());
                } else {
                    println("  References address " + toAddr);
                    
                    // Try to read as potential message map
                    analyzeAsMessageMap(toAddr);
                }
            }
            
        } catch (Exception e) {
            println("Error analyzing GetMessageMap function: " + e.getMessage());
        }
    }
    
    /**
     * Analyze an address as a potential message map
     */
    private void analyzeAsMessageMap(Address addr) {
        try {
            Memory memory = currentProgram.getMemory();
            int ptrSize = currentProgram.getDefaultPointerSize();
            
            // Read potential AFX_MSGMAP structure
            long baseMapPtr = ptrSize == 8 ? memory.getLong(addr) : memory.getInt(addr) & 0xFFFFFFFFL;
            long entriesPtr = ptrSize == 8 ? memory.getLong(addr.add(ptrSize)) : memory.getInt(addr.add(ptrSize)) & 0xFFFFFFFFL;
            
            println("    Potential message map structure:");
            println("      Base map pointer: 0x" + Long.toHexString(baseMapPtr));
            println("      Entries pointer: 0x" + Long.toHexString(entriesPtr));
            
            if (entriesPtr != 0) {
                Address entriesAddr = currentProgram.getAddressFactory().getDefaultAddressSpace().getAddress(entriesPtr);
                println("      Analyzing entries at " + entriesAddr);
                analyzeMessageMapEntries(entriesAddr);
            }
            
        } catch (Exception e) {
            println("    Error reading message map: " + e.getMessage());
        }
    }
    
    /**
     * Analyze message map entries
     */
    private void analyzeMessageMapEntries(Address entriesAddr) {
        try {
            Memory memory = currentProgram.getMemory();
            Address currentAddr = entriesAddr;
            int entrySize = currentProgram.getDefaultPointerSize() == 8 ? 32 : 24; // Approximate
            
            println("      Message map entries:");
            
            for (int i = 0; i < 5; i++) { // Limit to first 5 entries for example
                long nMessage = memory.getInt(currentAddr) & 0xFFFFFFFFL;
                long nCode = memory.getInt(currentAddr.add(4)) & 0xFFFFFFFFL;
                long nID = memory.getInt(currentAddr.add(8)) & 0xFFFFFFFFL;
                
                // Check for terminator
                if (nMessage == 0 && nCode == 0 && nID == 0) {
                    println("        [" + i + "] Terminator entry");
                    break;
                }
                
                String messageDesc = getMessageDescription(nMessage);
                println("        [" + i + "] " + messageDesc + ", Code: " + nCode + ", ID: " + nID);
                
                currentAddr = currentAddr.add(entrySize);
            }
            
        } catch (Exception e) {
            println("      Error reading entries: " + e.getMessage());
        }
    }
    
    /**
     * Get description for a message ID
     */
    private String getMessageDescription(long messageId) {
        switch ((int)messageId) {
            case 0x0111: return "WM_COMMAND";
            case 0x0112: return "WM_SYSCOMMAND";
            case 0x000F: return "WM_PAINT";
            case 0x0001: return "WM_CREATE";
            case 0x0002: return "WM_DESTROY";
            case 0x0005: return "WM_SIZE";
            default: return "0x" + Long.toHexString(messageId);
        }
    }
    
    /**
     * Show analysis results summary
     */
    private void showResults() {
        println("--- Analysis Results Summary ---");
        
        // Count functions
        FunctionManager funcMgr = currentProgram.getFunctionManager();
        int totalFunctions = funcMgr.getFunctionCount();
        
        // Count symbols
        SymbolTable symbolTable = currentProgram.getSymbolTable();
        int totalSymbols = symbolTable.getNumSymbols();
        
        // Count data types
        DataTypeManager dtm = currentProgram.getDataTypeManager();
        int totalDataTypes = dtm.getDataTypeCount(true);
        
        println("Program Statistics:");
        println("  Total functions: " + totalFunctions);
        println("  Total symbols: " + totalSymbols);
        println("  Total data types: " + totalDataTypes);
        println("  Architecture: " + currentProgram.getLanguage().getProcessor());
        println("  Pointer size: " + currentProgram.getDefaultPointerSize() + " bytes");
        
        println("\\nNext Steps:");
        println("1. Run the complete MFC analysis suite for detailed results");
        println("2. Check the Symbol Tree for organized MFC classes");
        println("3. Review function comments for message handler information");
        println("4. Use cross-references to understand message flow");
    }
}

