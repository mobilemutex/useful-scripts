# MFC Ghidra Scripts Installation Guide

## Quick Installation

1. **Download the script suite** to your local machine
2. **Copy the entire `mfc_ghidra_scripts` directory** to your Ghidra scripts folder:
   - **Windows**: `%USERPROFILE%\ghidra_scripts\`
   - **Linux/Mac**: `~/ghidra_scripts/`
   - **Custom**: Your configured Ghidra script directory

3. **Open Ghidra** and go to `Window > Script Manager`
4. **Click "Refresh"** to load the new scripts
5. **Verify installation** by looking for the "MFC" category in the script list

## Detailed Installation Steps

### Step 1: Locate Your Ghidra Scripts Directory

**Method 1: Check Ghidra Settings**
1. Open Ghidra
2. Go to `Edit > Tool Options`
3. Navigate to `Options > Scripting`
4. Note the "Script Directories" paths

**Method 2: Default Locations**
- **Windows**: `C:\Users\[username]\ghidra_scripts\`
- **Linux**: `/home/[username]/ghidra_scripts/`
- **macOS**: `/Users/[username]/ghidra_scripts/`

### Step 2: Copy Script Files

Copy the entire directory structure:
```
ghidra_scripts/
└── mfc_ghidra_scripts/
    ├── MFCAnalyzer.java              # Main orchestrator
    ├── core/                         # Core analysis scripts
    │   ├── MFCStructures.java
    │   ├── MFCMessageMapScanner.java
    │   ├── MFCClassAnalyzer.java
    │   ├── MFCMessageMapper.java
    │   └── MFCControlResolver.java
    ├── utils/                        # Utility scripts
    │   └── MFCSymbolNamer.java
    ├── examples/                     # Example scripts
    │   └── SimpleMFCExample.java
    └── docs/                         # Documentation
        ├── README.md
        ├── USAGE_GUIDE.md
        └── INSTALL.md
```

### Step 3: Verify Installation

1. **Open Ghidra**
2. **Open the Script Manager** (`Window > Script Manager`)
3. **Click "Refresh"** button
4. **Look for "MFC" category** in the script tree
5. **Expand the MFC category** to see all scripts

You should see:
- **MFC**
  - `MFCAnalyzer.java` (Run Complete Analysis)
  - **MFC.Core**
    - `MFCStructures.java`
    - `MFCMessageMapScanner.java`
    - `MFCClassAnalyzer.java`
    - `MFCMessageMapper.java`
    - `MFCControlResolver.java`
  - **MFC.Utils**
    - `MFCSymbolNamer.java`
  - **MFC.Examples**
    - `SimpleMFCExample.java`

## Troubleshooting Installation

### Scripts Not Appearing

**Problem**: Scripts don't show up in Script Manager

**Solutions**:
1. **Check file permissions** - ensure scripts are readable
2. **Verify file extensions** - all scripts should end in `.java`
3. **Check syntax** - scripts with syntax errors won't load
4. **Restart Ghidra** - sometimes required for new script directories
5. **Check Ghidra console** for error messages

### Permission Issues

**Problem**: Cannot copy files to scripts directory

**Solutions**:
1. **Run as administrator** (Windows) or use `sudo` (Linux/Mac)
2. **Change directory permissions** to allow write access
3. **Use alternative script directory** that you have write access to

### Path Issues

**Problem**: Scripts copied but not in expected location

**Solutions**:
1. **Verify script directory path** in Ghidra settings
2. **Add custom script directory** in Ghidra options
3. **Use absolute paths** when configuring script directories

## Configuration

### Script Categories

The scripts are organized into categories for easy navigation:

- **MFC**: Main analysis scripts
- **MFC.Core**: Core analysis components
- **MFC.Utils**: Utility and enhancement scripts
- **MFC.Examples**: Example and tutorial scripts

### Menu Integration

After installation, scripts will be available in:
- **Script Manager**: All scripts listed by category
- **Tools Menu**: `Tools > MFC > [Script Name]`
- **Toolbar**: If toolbar icons are configured

### Keyboard Shortcuts

You can assign keyboard shortcuts to frequently used scripts:
1. Right-click script in Script Manager
2. Select "Assign Key Binding"
3. Choose your preferred key combination

## Updating Scripts

To update the script suite:

1. **Backup your current scripts** (if you've made modifications)
2. **Download the new version**
3. **Replace the old `mfc_ghidra_scripts` directory**
4. **Refresh the Script Manager**
5. **Test with a known MFC application**

## Uninstallation

To remove the MFC scripts:

1. **Close Ghidra**
2. **Delete the `mfc_ghidra_scripts` directory** from your scripts folder
3. **Restart Ghidra**
4. **Refresh Script Manager** to confirm removal

## Verification Test

To verify the installation works correctly:

1. **Open a known MFC application** in Ghidra
2. **Run the complete auto-analysis** first
3. **Execute `SimpleMFCExample.java`** from the Examples category
4. **Check console output** for analysis results
5. **If successful, try `MFCAnalyzer.java`** for complete analysis

## System Requirements

- **Ghidra**: Version 10.0 or later
- **Java**: Compatible with Ghidra's Java version
- **Memory**: At least 4GB RAM for large applications
- **Disk Space**: Minimal (scripts are small)

## Support

If you encounter installation issues:

1. **Check the console output** in Ghidra for error messages
2. **Verify file permissions** and paths
3. **Test with the simple example** script first
4. **Review the documentation** in the `docs/` directory
5. **Check Ghidra's scripting documentation** for general scripting issues

## Next Steps

After successful installation:

1. **Read the README.md** for an overview of capabilities
2. **Review USAGE_GUIDE.md** for detailed usage instructions
3. **Try the SimpleMFCExample** on a test application
4. **Run complete analysis** on your target MFC application
5. **Explore the generated results** in Ghidra's interface

The scripts are now ready to help you reverse engineer MFC applications!

