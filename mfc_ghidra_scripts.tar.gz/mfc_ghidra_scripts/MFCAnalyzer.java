//MFC Analyzer - Main Orchestrator Script
//Runs complete MFC analysis workflow for reverse engineering MFC applications
//@author MFC Analysis Scripts
//@category MFC
//@keybinding 
//@menupath Tools.MFC.Run Complete Analysis
//@toolbar 

import ghidra.app.script.GhidraScript;
import ghidra.app.script.GhidraScriptUtil;
import ghidra.program.model.listing.Program;
import ghidra.util.exception.CancelledException;
import java.io.File;
import java.util.*;

public class MFCAnalyzer extends GhidraScript {
    
    private List<String> analysisSteps;
    private Map<String, Boolean> stepResults;
    private long startTime;
    
    @Override
    public void run() throws Exception {
        startTime = System.currentTimeMillis();
        analysisSteps = new ArrayList<>();
        stepResults = new HashMap<>();
        
        println("=== MFC Complete Analysis Started ===");
        println("Program: " + currentProgram.getName());
        println("Architecture: " + currentProgram.getLanguage().getProcessor());
        println("Pointer Size: " + currentProgram.getDefaultPointerSize() + " bytes");
        println("Date: " + new Date());
        println();
        
        // Check if this looks like an MFC application
        if (!isMFCApplication()) {
            println("WARNING: This does not appear to be an MFC application.");
            if (!askYesNo("Continue Analysis?", "Continue with MFC analysis anyway?")) {
                return;
            }
        }
        
        // Run analysis workflow
        runAnalysisWorkflow();
        
        // Generate final report
        generateFinalReport();
        
        long duration = System.currentTimeMillis() - startTime;
        println("\\n=== MFC Analysis Completed ===");
        println("Total time: " + (duration / 1000.0) + " seconds");
    }
    
    /**
     * Check if the program appears to be an MFC application
     */
    private boolean isMFCApplication() {
        // Look for MFC indicators
        boolean hasMFCStrings = false;
        boolean hasMFCImports = false;
        boolean hasMFCSymbols = false;
        
        // Check for MFC-related strings
        String[] mfcStrings = {
            "Microsoft Foundation Classes",
            "CWnd", "CDialog", "CView", "CDocument", "CFrameWnd",
            "AFX_", "GetMessageMap", "OnCommand", "UpdateUI"
        };
        
        for (String mfcString : mfcStrings) {
            if (findString(mfcString) != null) {
                hasMFCStrings = true;
                break;
            }
        }
        
        // Check for MFC-related imports
        String[] mfcImports = {
            "mfc", "MFC", "afxwin", "afxext", "afxcmn"
        };
        
        // This is a simplified check - in practice, you'd examine the import table
        for (String mfcImport : mfcImports) {
            if (findString(mfcImport) != null) {
                hasMFCImports = true;
                break;
            }
        }
        
        // Check for MFC-related symbols
        if (currentProgram.getSymbolTable().getSymbols("GetMessageMap").hasNext() ||
            currentProgram.getSymbolTable().getSymbols("OnCommand").hasNext()) {
            hasMFCSymbols = true;
        }
        
        println("MFC Detection Results:");
        println("  MFC Strings: " + (hasMFCStrings ? "Found" : "Not found"));
        println("  MFC Imports: " + (hasMFCImports ? "Found" : "Not found"));
        println("  MFC Symbols: " + (hasMFCSymbols ? "Found" : "Not found"));
        println();
        
        return hasMFCStrings || hasMFCImports || hasMFCSymbols;
    }
    
    /**
     * Find a string in the program
     */
    private ghidra.program.model.address.Address findString(String searchString) {
        try {
            ghidra.program.model.mem.Memory memory = currentProgram.getMemory();
            ghidra.program.model.address.AddressSetView searchSet = memory.getLoadedAndInitializedAddressSet();
            
            return memory.findBytes(searchSet.getMinAddress(), searchString.getBytes(), 
                                  null, true, monitor);
        } catch (Exception e) {
            return null;
        }
    }
    
    /**
     * Run the complete analysis workflow
     */
    private void runAnalysisWorkflow() throws Exception {
        // Step 1: Define MFC structures
        runAnalysisStep("Define MFC Structures", "MFCStructures.java");
        
        // Step 2: Scan for message maps
        runAnalysisStep("Scan Message Maps", "MFCMessageMapScanner.java");
        
        // Step 3: Analyze class hierarchy
        runAnalysisStep("Analyze Class Hierarchy", "MFCClassAnalyzer.java");
        
        // Step 4: Map message handlers
        runAnalysisStep("Map Message Handlers", "MFCMessageMapper.java");
        
        // Step 5: Resolve control IDs
        runAnalysisStep("Resolve Control IDs", "MFCControlResolver.java");
        
        // Step 6: Run utility scripts
        runUtilityScripts();
    }
    
    /**
     * Run a single analysis step
     */
    private void runAnalysisStep(String stepName, String scriptName) {
        println("\\n--- " + stepName + " ---");
        analysisSteps.add(stepName);
        
        try {
            // Find and run the script
            File scriptFile = findScript(scriptName);
            if (scriptFile != null) {
                println("Running: " + scriptName);
                
                // Run the script
                GhidraScript script = GhidraScriptUtil.newScriptInstance(scriptFile);
                if (script != null) {
                    script.set(state, monitor, writer);
                    script.run();
                    stepResults.put(stepName, true);
                    println("✓ " + stepName + " completed successfully");
                } else {
                    stepResults.put(stepName, false);
                    println("✗ Failed to create script instance: " + scriptName);
                }
            } else {
                stepResults.put(stepName, false);
                println("✗ Script not found: " + scriptName);
            }
            
        } catch (Exception e) {
            stepResults.put(stepName, false);
            println("✗ " + stepName + " failed: " + e.getMessage());
        }
    }
    
    /**
     * Find a script file
     */
    private File findScript(String scriptName) {
        // Look in the core directory
        File coreDir = new File(getScriptDirectories().get(0), "core");
        File scriptFile = new File(coreDir, scriptName);
        
        if (scriptFile.exists()) {
            return scriptFile;
        }
        
        // Look in the main script directory
        for (File scriptDir : getScriptDirectories()) {
            scriptFile = new File(scriptDir, scriptName);
            if (scriptFile.exists()) {
                return scriptFile;
            }
        }
        
        return null;
    }
    
    /**
     * Run utility scripts
     */
    private void runUtilityScripts() {
        println("\\n--- Running Utility Scripts ---");
        
        // Run utility scripts if they exist
        String[] utilityScripts = {
            "MFCSymbolNamer.java",
            "MFCBookmarkCreator.java",
            "MFCCommentGenerator.java"
        };
        
        for (String scriptName : utilityScripts) {
            try {
                File scriptFile = findScript(scriptName);
                if (scriptFile != null) {
                    println("Running utility: " + scriptName);
                    GhidraScript script = GhidraScriptUtil.newScriptInstance(scriptFile);
                    if (script != null) {
                        script.set(state, monitor, writer);
                        script.run();
                        println("✓ " + scriptName + " completed");
                    }
                } else {
                    println("- " + scriptName + " not found (optional)");
                }
            } catch (Exception e) {
                println("✗ " + scriptName + " failed: " + e.getMessage());
            }
        }
    }
    
    /**
     * Generate final analysis report
     */
    private void generateFinalReport() {
        println("\\n=== MFC Analysis Report ===");
        
        // Analysis steps summary
        println("\\nAnalysis Steps:");
        for (String step : analysisSteps) {
            Boolean success = stepResults.get(step);
            String status = success != null && success ? "✓ PASSED" : "✗ FAILED";
            println("  " + status + " " + step);
        }
        
        // Statistics
        int passedSteps = 0;
        for (Boolean result : stepResults.values()) {
            if (result != null && result) passedSteps++;
        }
        
        println("\\nSummary:");
        println("  Steps completed: " + passedSteps + "/" + analysisSteps.size());
        println("  Success rate: " + (passedSteps * 100 / analysisSteps.size()) + "%");
        
        // Recommendations
        generateRecommendations();
        
        // Next steps
        println("\\nNext Steps:");
        println("1. Review the analysis results in the Symbol Tree");
        println("2. Check function comments for message handler information");
        println("3. Use the cross-references to understand message flow");
        println("4. Examine the class hierarchy in the namespace view");
        println("5. Look for control ID symbols in the equates");
        
        // Export options
        println("\\nExport Options:");
        println("- Use 'Tools > MFC > Generate HTML Report' for detailed documentation");
        println("- Export symbols and comments for external analysis");
        println("- Create bookmarks for important MFC structures");
    }
    
    /**
     * Generate analysis recommendations
     */
    private void generateRecommendations() {
        println("\\nRecommendations:");
        
        if (!stepResults.getOrDefault("Define MFC Structures", false)) {
            println("⚠ MFC structures not defined - manual structure creation may be needed");
        }
        
        if (!stepResults.getOrDefault("Scan Message Maps", false)) {
            println("⚠ Message maps not found - check if this is truly an MFC application");
        }
        
        if (!stepResults.getOrDefault("Analyze Class Hierarchy", false)) {
            println("⚠ Class hierarchy analysis failed - manual class identification needed");
        }
        
        if (!stepResults.getOrDefault("Map Message Handlers", false)) {
            println("⚠ Message mapping incomplete - some handlers may not be identified");
        }
        
        if (!stepResults.getOrDefault("Resolve Control IDs", false)) {
            println("⚠ Control ID resolution failed - resource section may be missing");
        }
        
        // Check for common issues
        if (currentProgram.getDefaultPointerSize() == 8) {
            println("ℹ 64-bit application detected - ensure structure sizes are correct");
        }
        
        if (currentProgram.getMemory().getBlock(".rsrc") == null) {
            println("ℹ No resource section found - control ID resolution will be limited");
        }
        
        // Success recommendations
        int successCount = 0;
        for (Boolean result : stepResults.values()) {
            if (result != null && result) successCount++;
        }
        
        if (successCount >= 4) {
            println("✓ Analysis largely successful - good MFC application structure detected");
        } else if (successCount >= 2) {
            println("⚠ Partial analysis success - some MFC patterns detected");
        } else {
            println("⚠ Limited analysis success - may not be a standard MFC application");
        }
    }
}

