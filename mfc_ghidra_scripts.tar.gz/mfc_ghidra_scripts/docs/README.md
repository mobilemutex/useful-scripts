# MFC Ghidra Scripts

A comprehensive suite of Ghidra scripts designed to aid in reverse engineering Microsoft Foundation Classes (MFC) C++ applications. These scripts help identify class hierarchies, map message handlers, resolve control IDs, and understand the overall structure of MFC applications.

## Overview

MFC applications use a complex message-driven architecture with class hierarchies, message maps, and resource-based UI elements. This script suite automates the analysis of these components to provide a clear understanding of the application's structure and behavior.

## Features

- **Automatic MFC Structure Detection**: Identifies and defines core MFC data structures
- **Message Map Analysis**: Locates and parses message map tables to understand event handling
- **Class Hierarchy Reconstruction**: Builds inheritance relationships between MFC classes
- **Message Handler Mapping**: Maps Windows messages to their handler functions
- **Control ID Resolution**: Resolves control IDs to actual UI elements from resources
- **Symbol Enhancement**: Creates meaningful symbol names for MFC components
- **Cross-Reference Generation**: Establishes relationships between UI elements and code

## Script Components

### Core Analysis Scripts

#### 1. MFCStructures.java
**Purpose**: Defines core MFC data structures in Ghidra's type system.

**What it does**:
- Creates `AFX_MSGMAP_ENTRY` structure for message map entries
- Creates `AFX_MSGMAP` structure for message map headers
- Creates `CRuntimeClass` structure for runtime type information
- Defines Windows message constants and MFC signature enums

**When to run**: First, before any other analysis scripts.

#### 2. MFCMessageMapScanner.java
**Purpose**: Locates and analyzes MFC message map structures.

**What it does**:
- Scans memory for message map patterns
- Parses message map entries to extract handler mappings
- Validates message map structures
- Creates symbols for message maps and handler functions
- Applies MFC structures to identified data

**Output**: Message map locations, handler function addresses, and structure annotations.

#### 3. MFCClassAnalyzer.java
**Purpose**: Reconstructs MFC class inheritance relationships.

**What it does**:
- Analyzes message map inheritance chains
- Identifies virtual function tables (vtables)
- Maps constructors and destructors to classes
- Creates class namespaces and organizes functions
- Builds class hierarchy visualization

**Output**: Class hierarchy tree, namespace organization, and vtable identification.

#### 4. MFCMessageMapper.java
**Purpose**: Maps message IDs to handler functions and creates cross-references.

**What it does**:
- Extracts message mappings from message map entries
- Identifies message types (commands, notifications, system messages)
- Creates cross-references between UI elements and handlers
- Enhances function comments with message information
- Generates comprehensive message mapping report

**Output**: Enhanced function comments, cross-references, and message flow documentation.

#### 5. MFCControlResolver.java
**Purpose**: Resolves control IDs to actual UI elements.

**What it does**:
- Parses resource section (.rsrc) for dialog and menu definitions
- Extracts string table entries
- Maps control IDs to UI element descriptions
- Creates symbols and equates for control IDs
- Analyzes control ID usage in code

**Output**: Control ID symbols, UI element descriptions, and resource mapping.

### Main Orchestrator

#### MFCAnalyzer.java
**Purpose**: Runs the complete MFC analysis workflow.

**What it does**:
- Detects if the program is an MFC application
- Executes all core analysis scripts in proper order
- Runs utility scripts for enhancement
- Generates comprehensive analysis report
- Provides recommendations and next steps

**When to run**: Use this for complete automated analysis of MFC applications.

### Utility Scripts

#### MFCSymbolNamer.java
**Purpose**: Creates meaningful symbol names for MFC functions and structures.

**What it does**:
- Renames message map symbols with class context
- Creates descriptive names for message handler functions
- Names constructors, destructors, and virtual functions
- Improves vtable symbol names
- Cleans up generic function names

## Installation

1. Copy the entire `mfc_ghidra_scripts` directory to your Ghidra scripts folder
2. In Ghidra, go to `Window > Script Manager`
3. Click the "Refresh" button to load the new scripts
4. The scripts will appear under the "MFC" category

## Usage

### Quick Start

1. Open your MFC application in Ghidra
2. Run the initial Ghidra analysis (Auto Analysis)
3. Go to `Tools > MFC > Run Complete Analysis` or run `MFCAnalyzer.java`
4. Review the analysis results and generated report

### Manual Step-by-Step Analysis

If you prefer to run individual components:

1. **Define Structures**: Run `MFCStructures.java`
2. **Scan Message Maps**: Run `MFCMessageMapScanner.java`
3. **Analyze Classes**: Run `MFCClassAnalyzer.java`
4. **Map Messages**: Run `MFCMessageMapper.java`
5. **Resolve Controls**: Run `MFCControlResolver.java`
6. **Enhance Symbols**: Run `MFCSymbolNamer.java`

### Viewing Results

After analysis, check these areas in Ghidra:

- **Symbol Tree**: Look for MFC class namespaces and organized functions
- **Data Type Manager**: Find MFC structures under `/MFC` category
- **Function Comments**: Enhanced with message handler information
- **Cross-References**: Follow message flow between UI and handlers
- **Equates**: Control ID and message constant definitions

## Understanding the Output

### Message Map Analysis

Message maps are the core of MFC's event handling system. The scripts identify:

- **Message Map Structures**: `AFX_MSGMAP` headers pointing to entry arrays
- **Message Entries**: Individual `AFX_MSGMAP_ENTRY` structures mapping messages to handlers
- **Handler Functions**: The actual code that processes messages
- **Class Relationships**: Inheritance chains through base message map pointers

### Class Hierarchy

MFC uses inheritance extensively. The analysis reconstructs:

- **Base Classes**: Common MFC classes like `CWnd`, `CDialog`, `CView`
- **Derived Classes**: Application-specific classes inheriting from MFC base classes
- **Virtual Functions**: Methods that can be overridden in derived classes
- **Constructor/Destructor Chains**: Object lifecycle management

### Message Types

The scripts recognize several message categories:

- **WM_COMMAND**: Menu selections and button clicks
- **Control Notifications**: Edit box changes, list selections, etc.
- **System Messages**: Window creation, painting, sizing, etc.
- **User Messages**: Application-defined custom messages
- **UPDATE_COMMAND_UI**: UI state update handlers

### Control ID Resolution

UI elements are identified through:

- **Dialog Resources**: Layout and control definitions
- **Menu Resources**: Menu structure and command IDs
- **String Tables**: Text associated with UI elements
- **Code References**: Where control IDs are used in the application

## Troubleshooting

### Common Issues

**"MFC structures not found"**
- Run `MFCStructures.java` first
- Check that the script completed successfully

**"No message maps found"**
- Verify this is actually an MFC application
- Check for stripped symbols or packed executables
- Look for message map patterns manually

**"Resource section not found"**
- Control ID resolution will be limited
- The application may not have embedded resources
- Resources might be in a separate file

**"Class hierarchy analysis failed"**
- Vtables may be obfuscated or missing
- Try manual identification of key classes
- Check for non-standard MFC usage

### Performance Considerations

- Large applications may take several minutes to analyze
- The scripts include safety limits to prevent infinite loops
- Monitor progress in Ghidra's console output
- Cancel analysis if it appears stuck

### Compatibility

- **Ghidra Version**: Tested with Ghidra 10.0+
- **Architecture**: Supports both 32-bit and 64-bit applications
- **MFC Versions**: Compatible with MFC 4.0 through current versions
- **Compilers**: Primarily tested with MSVC-compiled applications

## Advanced Usage

### Customizing Analysis

You can modify the scripts for specific needs:

- **Add Custom Message Types**: Extend message recognition in `MFCMessageMapper.java`
- **Custom Control Types**: Add new control patterns in `MFCControlResolver.java`
- **Naming Conventions**: Modify symbol naming in `MFCSymbolNamer.java`

### Integration with Other Tools

The analysis results can be exported for use with:

- **IDA Pro**: Export symbols and comments
- **x64dbg**: Use control ID information for debugging
- **Resource Editors**: Cross-reference with original resources

### Scripting Extensions

Create additional scripts that build on this analysis:

- **UI Flow Analysis**: Track user interaction paths
- **Security Analysis**: Identify input validation in handlers
- **Documentation Generation**: Create detailed application documentation

## Examples

### Typical MFC Application Structure

```
MyApp
├── CMyApp (Application class)
│   ├── InitInstance()
│   └── ExitInstance()
├── CMainFrame (Main window)
│   ├── OnCreate()
│   ├── OnCommand_FileNew()
│   └── OnUpdateUI_FileSave()
├── CMyDoc (Document class)
│   ├── OnNewDocument()
│   └── Serialize()
└── CMyView (View class)
    ├── OnDraw()
    ├── OnLButtonDown()
    └── OnCommand_EditCopy()
```

### Message Map Example

```cpp
// What the scripts identify:
BEGIN_MESSAGE_MAP(CMyView, CView)
    ON_WM_LBUTTONDOWN()           // Maps to OnLButtonDown()
    ON_COMMAND(ID_EDIT_COPY, OnEditCopy)  // Maps to OnEditCopy()
    ON_UPDATE_COMMAND_UI(ID_EDIT_COPY, OnUpdateEditCopy)
END_MESSAGE_MAP()
```

## Contributing

To extend or improve these scripts:

1. Follow Ghidra's scripting conventions
2. Add comprehensive error handling
3. Include progress monitoring for long operations
4. Document new features and usage
5. Test with various MFC application types

## License

These scripts are provided as-is for educational and research purposes. Use responsibly and in accordance with applicable laws and regulations.

## Support

For issues or questions:

1. Check the troubleshooting section above
2. Review Ghidra's scripting documentation
3. Examine the script source code for implementation details
4. Test with known MFC applications to verify functionality

