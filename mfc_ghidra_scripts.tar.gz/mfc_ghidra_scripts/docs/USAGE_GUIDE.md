# MFC Ghidra Scripts Usage Guide

This guide provides detailed instructions and examples for using the MFC Ghidra Scripts to reverse engineer MFC applications effectively.

## Prerequisites

Before using these scripts, ensure you have:

1. **Ghidra 10.0 or later** installed and configured
2. **Basic understanding of MFC architecture** (classes, message maps, resources)
3. **Familiarity with Ghidra's interface** (Symbol Tree, Data Type Manager, etc.)
4. **An MFC application** loaded in Ghidra with initial auto-analysis completed

## Step-by-Step Walkthrough

### Step 1: Initial Setup

1. **Load your MFC application** into Ghidra
2. **Run Ghidra's auto-analysis** (Analysis > Auto Analyze)
3. **Install the MFC scripts** in your Ghidra scripts directory
4. **Refresh the Script Manager** (Window > Script Manager > Refresh)

### Step 2: Verify MFC Application

Before running the analysis, verify you have an MFC application:

**Look for these indicators:**
- Strings containing "MFC", "AFX_", or class names like "CWnd", "CDialog"
- Import references to MFC libraries (mfc*.dll)
- Message map symbols or GetMessageMap functions

**Quick verification script:**
```java
// Run this in Ghidra's Script Manager to check for MFC indicators
currentProgram.getMemory().findBytes(
    currentProgram.getMemory().getMinAddress(),
    "Microsoft Foundation Classes".getBytes(),
    null, true, monitor
);
```

### Step 3: Run Complete Analysis

**Option A: Automated Analysis (Recommended)**
1. Go to `Tools > MFC > Run Complete Analysis`
2. Or run `MFCAnalyzer.java` from Script Manager
3. Review the console output for progress and results
4. Check the final analysis report

**Option B: Manual Step-by-Step**
1. Run `MFCStructures.java` - Defines MFC data types
2. Run `MFCMessageMapScanner.java` - Finds message maps
3. Run `MFCClassAnalyzer.java` - Builds class hierarchy
4. Run `MFCMessageMapper.java` - Maps message handlers
5. Run `MFCControlResolver.java` - Resolves UI controls
6. Run `MFCSymbolNamer.java` - Improves symbol names

## Interpreting Results

### Message Map Analysis

After running the message map scanner, you'll see:

**In the Console:**
```
Found message map at 00401234 with entries at 00401250 (5 entries)
Mapped Command ID 1001 -> 00402000 in CMainFrame
Mapped WM_PAINT -> 00402100 in CMyView
```

**In the Symbol Tree:**
- `CMainFrame_messageMap` - The message map structure
- `CMainFrame_messageEntries` - Array of message entries
- `CMainFrame_Handler_0` - Individual handler functions

**In the Data Type Manager:**
- `/MFC/AFX_MSGMAP` - Message map structure definition
- `/MFC/AFX_MSGMAP_ENTRY` - Message entry structure

### Class Hierarchy Visualization

The class analyzer produces a hierarchy like this:

```
CWnd (15 methods, 8 messages)
  CFrameWnd (12 methods, 6 messages)
    CMainFrame (8 methods, 12 messages)
  CView (10 methods, 5 messages)
    CMyView (6 methods, 8 messages)
CDialog (8 methods, 4 messages)
  CMyDialog (4 methods, 6 messages)
```

**Understanding the output:**
- **Methods**: Total member functions identified
- **Messages**: Number of message handlers in this class
- **Indentation**: Shows inheritance relationships

### Message Handler Information

Enhanced function comments will show:

```cpp
=== MFC Message Handler ===
Class: CMainFrame
Message: WM_COMMAND (0x111)
Type: COMMAND
Command ID: 1001
Description: Command ID 1001
```

**Message Types Explained:**
- **COMMAND**: Menu selections, button clicks (nCode = 0)
- **CONTROL_NOTIFICATION**: Edit changes, list selections (nCode > 0)
- **SYSTEM_MESSAGE**: Windows messages (WM_PAINT, WM_SIZE, etc.)
- **UPDATE_UI**: UI state update handlers
- **USER_MESSAGE**: Custom application messages

### Control ID Resolution

The control resolver identifies UI elements:

**Dialog Controls:**
```
Dialog: IDD_MAIN_DIALOG (ID: 1000)
  Size: 320x240 at (0,0)
  Controls: 5
    ID 1001 (BUTTON) "OK" in IDD_MAIN_DIALOG
    ID 1002 (EDIT) "" in IDD_MAIN_DIALOG
    ID 1003 (STATIC) "Enter Name:" in IDD_MAIN_DIALOG
```

**Menu Items:**
```
Menu Items (8):
  ID 1010: "File"
  ID 1011: "New"
  ID 1012: "Open"
  ID 1013: "Save"
```

## Common Analysis Patterns

### Pattern 1: Dialog-Based Application

**Characteristics:**
- Main class inherits from `CDialog`
- Message map handles `WM_INITDIALOG`, `WM_COMMAND`
- Control IDs map to dialog resource

**Analysis Focus:**
1. Identify the main dialog class
2. Map control IDs to UI elements
3. Trace button click handlers
4. Understand data validation logic

**Example Analysis:**
```
CMyDialog::OnInitDialog()     // Dialog initialization
CMyDialog::OnOK()            // OK button handler
CMyDialog::OnCancel()        // Cancel button handler
CMyDialog::OnBnClickedButton1() // Custom button handler
```

### Pattern 2: Document/View Application

**Characteristics:**
- Separate document and view classes
- Frame window coordinates between them
- Complex message routing

**Analysis Focus:**
1. Identify document, view, and frame classes
2. Understand message routing between classes
3. Map menu commands to document operations
4. Trace view update mechanisms

**Example Structure:**
```
CMainFrame (coordinates UI)
├── File menu handlers
├── View menu handlers
└── Status bar updates

CMyDoc (data management)
├── File operations (New, Open, Save)
├── Data modification methods
└── Serialization

CMyView (display)
├── Drawing operations (OnDraw)
├── User input handlers
└── Document interaction
```

### Pattern 3: MDI Application

**Characteristics:**
- Multiple document interface
- Child frame windows
- Complex window management

**Analysis Focus:**
1. Identify MDI frame and child frame classes
2. Map document type associations
3. Understand window switching logic
4. Trace document creation/destruction

## Advanced Techniques

### Custom Message Analysis

To analyze custom messages (WM_USER + offset):

1. **Identify custom message constants:**
   ```cpp
   #define WM_CUSTOM_UPDATE (WM_USER + 100)
   ```

2. **Look for PostMessage/SendMessage calls:**
   - Search for the message constant value
   - Trace message posting locations
   - Find corresponding handlers

3. **Extend the message mapper:**
   - Add custom message names to `MFCMessageMapper.java`
   - Enhance message type detection

### Resource Analysis Integration

Combine script results with resource analysis:

1. **Export resource information** from the script output
2. **Use resource editors** to view original UI layouts
3. **Cross-reference** control IDs between code and resources
4. **Identify missing or unused** UI elements

### Dynamic Analysis Correlation

Use script results to guide dynamic analysis:

1. **Set breakpoints** on identified message handlers
2. **Monitor message flow** during application execution
3. **Validate static analysis** with runtime behavior
4. **Identify code paths** not visible in static analysis

## Troubleshooting Common Issues

### Issue: No Message Maps Found

**Possible Causes:**
- Not an MFC application
- Stripped symbols
- Packed/obfuscated executable
- Non-standard MFC usage

**Solutions:**
1. **Verify MFC indicators** manually
2. **Check for string references** to MFC classes
3. **Look for GetMessageMap** function patterns
4. **Search for message map signatures** manually

**Manual Search Example:**
```java
// Search for AFX_MSGMAP_ENTRY patterns
Memory memory = currentProgram.getMemory();
// Look for sequences of 6 DWORDs (32-bit) or DWORD+QWORD+PTR (64-bit)
```

### Issue: Incomplete Class Hierarchy

**Possible Causes:**
- Missing vtable information
- Optimized builds
- Template-based inheritance

**Solutions:**
1. **Manually identify key classes** from strings/symbols
2. **Look for constructor patterns** (vtable initialization)
3. **Analyze function call patterns** for inheritance
4. **Use cross-references** to build relationships

### Issue: Control IDs Not Resolved

**Possible Causes:**
- No resource section
- External resource files
- Dynamically created controls

**Solutions:**
1. **Check for .rsrc section** in memory map
2. **Look for external .rc files** or resource DLLs
3. **Search for CreateWindow calls** with control IDs
4. **Analyze dialog template parsing** code

## Best Practices

### Before Analysis

1. **Complete Ghidra's auto-analysis** first
2. **Review memory map** for resource sections
3. **Check import table** for MFC dependencies
4. **Identify entry points** and main functions

### During Analysis

1. **Monitor console output** for progress and errors
2. **Save project frequently** to preserve results
3. **Take notes** on interesting findings
4. **Cross-reference** results with external documentation

### After Analysis

1. **Review all generated symbols** and comments
2. **Validate findings** with known application behavior
3. **Export results** for external analysis tools
4. **Document custom findings** and modifications

### Performance Optimization

1. **Limit analysis scope** for large applications
2. **Use specific scripts** instead of complete analysis
3. **Monitor memory usage** during analysis
4. **Cancel stuck operations** and retry with smaller scope

## Integration with Other Tools

### IDA Pro Integration

Export Ghidra results for IDA Pro:

1. **Export symbols** with meaningful names
2. **Export comments** with message handler information
3. **Create IDC scripts** to recreate structures
4. **Transfer control ID mappings**

### Debugging Integration

Use analysis results for debugging:

1. **Set breakpoints** on message handlers
2. **Monitor control ID usage** during execution
3. **Trace message flow** through the application
4. **Validate static analysis** with dynamic behavior

### Documentation Generation

Create comprehensive documentation:

1. **Export class hierarchy** to documentation tools
2. **Generate message flow diagrams**
3. **Create UI element mappings**
4. **Document reverse engineering findings**

## Example Workflows

### Workflow 1: Understanding a Dialog Application

1. **Run complete MFC analysis**
2. **Identify main dialog class** from hierarchy
3. **Map all control IDs** to UI elements
4. **Trace button click handlers**
5. **Understand data flow** and validation
6. **Document user interaction paths**

### Workflow 2: Analyzing Menu Command Handling

1. **Run message mapper** to identify command handlers
2. **Resolve menu item IDs** from resources
3. **Trace command routing** through frame classes
4. **Identify update UI handlers**
5. **Map keyboard shortcuts** to commands
6. **Document command implementation**

### Workflow 3: Reverse Engineering Custom Controls

1. **Identify custom control classes** in hierarchy
2. **Analyze message handling** for custom messages
3. **Map control notifications** to parent handlers
4. **Understand drawing operations** (WM_PAINT handlers)
5. **Trace user input processing**
6. **Document control behavior**

This guide provides a foundation for effectively using the MFC Ghidra Scripts. Adapt these techniques to your specific reverse engineering goals and application characteristics.

