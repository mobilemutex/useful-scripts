//MFC Symbol Namer
//Creates meaningful symbol names for MFC functions and data structures
//@author MFC Analysis Scripts
//@category MFC.Utils
//@keybinding 
//@menupath Tools.MFC.Utils.Create MFC Symbol Names
//@toolbar 

import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.*;
import ghidra.program.model.listing.*;
import ghidra.program.model.symbol.*;
import ghidra.util.exception.CancelledException;
import java.util.*;

public class MFCSymbolNamer extends GhidraScript {
    
    private SymbolTable symbolTable;
    private Map<String, Integer> classCounters;
    private Set<String> createdSymbols;
    
    @Override
    public void run() throws Exception {
        symbolTable = currentProgram.getSymbolTable();
        classCounters = new HashMap<>();
        createdSymbols = new HashSet<>();
        
        println("Creating meaningful MFC symbol names...");
        
        // Step 1: Name message map related symbols
        nameMessageMapSymbols();
        
        // Step 2: Name MFC class methods
        nameMFCClassMethods();
        
        // Step 3: Name common MFC patterns
        nameCommonMFCPatterns();
        
        // Step 4: Name vtable symbols
        nameVtableSymbols();
        
        // Step 5: Clean up generic symbols
        cleanupGenericSymbols();
        
        println("Symbol naming completed!");
        println("Created " + createdSymbols.size() + " meaningful symbol names");
    }
    
    /**
     * Name message map related symbols
     */
    private void nameMessageMapSymbols() throws CancelledException {
        println("Naming message map symbols...");
        
        SymbolIterator symbols = symbolTable.getAllSymbols(true);
        while (symbols.hasNext()) {
            monitor.checkCanceled();
            Symbol symbol = symbols.next();
            String name = symbol.getName();
            
            if (name.contains("messageMap") || name.contains("MessageMap")) {
                improveMessageMapSymbol(symbol);
            } else if (name.contains("messageEntries") || name.contains("MessageEntries")) {
                improveMessageEntriesSymbol(symbol);
            }
        }
    }
    
    /**
     * Improve message map symbol name
     */
    private void improveMessageMapSymbol(Symbol symbol) {
        try {
            String className = extractClassNameFromSymbol(symbol.getName());
            String newName = className + "::GetMessageMap_Map";
            
            if (!createdSymbols.contains(newName)) {
                symbol.setName(newName, SourceType.ANALYSIS);
                createdSymbols.add(newName);
                println("Renamed: " + symbol.getName() + " -> " + newName);
            }
            
        } catch (Exception e) {
            // Symbol rename failed
        }
    }
    
    /**
     * Improve message entries symbol name
     */
    private void improveMessageEntriesSymbol(Symbol symbol) {
        try {
            String className = extractClassNameFromSymbol(symbol.getName());
            String newName = className + "::MessageEntries";
            
            if (!createdSymbols.contains(newName)) {
                symbol.setName(newName, SourceType.ANALYSIS);
                createdSymbols.add(newName);
                println("Renamed: " + symbol.getName() + " -> " + newName);
            }
            
        } catch (Exception e) {
            // Symbol rename failed
        }
    }
    
    /**
     * Name MFC class methods
     */
    private void nameMFCClassMethods() throws CancelledException {
        println("Naming MFC class methods...");
        
        FunctionManager funcMgr = currentProgram.getFunctionManager();
        FunctionIterator functions = funcMgr.getFunctions(true);
        
        while (functions.hasNext()) {
            monitor.checkCanceled();
            Function func = functions.next();
            
            if (isMFCFunction(func)) {
                improveMFCFunctionName(func);
            }
        }
    }
    
    /**
     * Check if function appears to be an MFC function
     */
    private boolean isMFCFunction(Function func) {
        String comment = func.getComment();
        if (comment != null && comment.contains("MFC Message Handler")) {
            return true;
        }
        
        // Check for MFC patterns in the function
        String funcName = func.getName();
        if (funcName.contains("Handler") || funcName.contains("OnCommand") || 
            funcName.contains("UpdateUI") || funcName.contains("OnNotify")) {
            return true;
        }
        
        // Check for references to message maps
        ReferenceManager refMgr = currentProgram.getReferenceManager();
        ReferenceIterator refs = refMgr.getReferencesFrom(func.getEntryPoint());
        
        while (refs.hasNext()) {
            Reference ref = refs.next();
            Symbol symbol = symbolTable.getPrimarySymbol(ref.getToAddress());
            if (symbol != null && symbol.getName().contains("messageMap")) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Improve MFC function name
     */
    private void improveMFCFunctionName(Function func) {
        try {
            String comment = func.getComment();
            if (comment == null) return;
            
            // Extract information from comment
            String className = extractClassNameFromComment(comment);
            String messageType = extractMessageTypeFromComment(comment);
            String controlInfo = extractControlInfoFromComment(comment);
            
            if (className != null && messageType != null) {
                String newName = buildFunctionName(className, messageType, controlInfo);
                
                if (!createdSymbols.contains(newName) && !newName.equals(func.getName())) {
                    func.setName(newName, SourceType.ANALYSIS);
                    createdSymbols.add(newName);
                    println("Renamed function: " + func.getName() + " -> " + newName);
                }
            }
            
        } catch (Exception e) {
            // Function rename failed
        }
    }
    
    /**
     * Extract class name from comment
     */
    private String extractClassNameFromComment(String comment) {
        if (comment.contains("Class: ")) {
            int start = comment.indexOf("Class: ") + 7;
            int end = comment.indexOf("\\n", start);
            if (end == -1) end = comment.length();
            return comment.substring(start, end).trim();
        }
        return null;
    }
    
    /**
     * Extract message type from comment
     */
    private String extractMessageTypeFromComment(String comment) {
        if (comment.contains("Message: ")) {
            int start = comment.indexOf("Message: ") + 9;
            int end = comment.indexOf("\\n", start);
            if (end == -1) end = comment.length();
            String message = comment.substring(start, end).trim();
            
            // Clean up message name
            if (message.contains("(")) {
                message = message.substring(0, message.indexOf("(")).trim();
            }
            
            return message;
        }
        return null;
    }
    
    /**
     * Extract control information from comment
     */
    private String extractControlInfoFromComment(String comment) {
        if (comment.contains("Command ID: ")) {
            int start = comment.indexOf("Command ID: ") + 12;
            int end = comment.indexOf("\\n", start);
            if (end == -1) end = comment.length();
            return "CMD_" + comment.substring(start, end).trim();
        }
        
        if (comment.contains("Control ID: ")) {
            int start = comment.indexOf("Control ID: ") + 12;
            int end = comment.indexOf("\\n", start);
            if (end == -1) end = comment.length();
            return "CTRL_" + comment.substring(start, end).trim();
        }
        
        return null;
    }
    
    /**
     * Build function name from components
     */
    private String buildFunctionName(String className, String messageType, String controlInfo) {
        StringBuilder name = new StringBuilder();
        name.append(className).append("::");
        
        // Convert message type to method name
        if (messageType.equals("WM_COMMAND")) {
            if (controlInfo != null && controlInfo.startsWith("CMD_")) {
                name.append("OnCommand_").append(controlInfo.substring(4));
            } else if (controlInfo != null && controlInfo.startsWith("CTRL_")) {
                name.append("OnControl_").append(controlInfo.substring(5));
            } else {
                name.append("OnCommand");
            }
        } else if (messageType.equals("UPDATE_COMMAND_UI")) {
            if (controlInfo != null && controlInfo.startsWith("CMD_")) {
                name.append("OnUpdateUI_").append(controlInfo.substring(4));
            } else {
                name.append("OnUpdateCommandUI");
            }
        } else if (messageType.startsWith("WM_")) {
            String methodName = "On" + messageType.substring(3);
            // Convert to proper case
            methodName = methodName.substring(0, 1).toUpperCase() + 
                        methodName.substring(1).toLowerCase();
            name.append(methodName);
        } else {
            name.append("OnMessage_").append(messageType);
        }
        
        return name.toString();
    }
    
    /**
     * Name common MFC patterns
     */
    private void nameCommonMFCPatterns() throws CancelledException {
        println("Naming common MFC patterns...");
        
        // Look for GetMessageMap functions
        nameGetMessageMapFunctions();
        
        // Look for constructor/destructor patterns
        nameConstructorDestructorPatterns();
        
        // Look for common MFC virtual functions
        nameCommonVirtualFunctions();
    }
    
    /**
     * Name GetMessageMap functions
     */
    private void nameGetMessageMapFunctions() throws CancelledException {
        FunctionManager funcMgr = currentProgram.getFunctionManager();
        FunctionIterator functions = funcMgr.getFunctions(true);
        
        while (functions.hasNext()) {
            monitor.checkCanceled();
            Function func = functions.next();
            
            if (isGetMessageMapFunction(func)) {
                String className = extractClassNameFromFunction(func);
                if (className != null) {
                    try {
                        String newName = className + "::GetMessageMap";
                        if (!createdSymbols.contains(newName)) {
                            func.setName(newName, SourceType.ANALYSIS);
                            createdSymbols.add(newName);
                            println("Named GetMessageMap: " + newName);
                        }
                    } catch (Exception e) {
                        // Rename failed
                    }
                }
            }
        }
    }
    
    /**
     * Check if function is GetMessageMap
     */
    private boolean isGetMessageMapFunction(Function func) {
        // Check if function returns a pointer to message map
        ReferenceManager refMgr = currentProgram.getReferenceManager();
        ReferenceIterator refs = refMgr.getReferencesFrom(func.getBody(), true);
        
        while (refs.hasNext()) {
            Reference ref = refs.next();
            Symbol symbol = symbolTable.getPrimarySymbol(ref.getToAddress());
            if (symbol != null && symbol.getName().contains("messageMap")) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Extract class name from function context
     */
    private String extractClassNameFromFunction(Function func) {
        // Look for nearby symbols or namespace
        Namespace namespace = func.getParentNamespace();
        if (namespace != null && !namespace.isGlobal()) {
            return namespace.getName();
        }
        
        // Look for class patterns in function name
        String funcName = func.getName();
        if (funcName.contains("::")) {
            return funcName.substring(0, funcName.indexOf("::"));
        }
        
        return null;
    }
    
    /**
     * Name constructor/destructor patterns
     */
    private void nameConstructorDestructorPatterns() throws CancelledException {
        FunctionManager funcMgr = currentProgram.getFunctionManager();
        FunctionIterator functions = funcMgr.getFunctions(true);
        
        while (functions.hasNext()) {
            monitor.checkCanceled();
            Function func = functions.next();
            
            if (isConstructorPattern(func)) {
                nameConstructor(func);
            } else if (isDestructorPattern(func)) {
                nameDestructor(func);
            }
        }
    }
    
    /**
     * Check if function is a constructor pattern
     */
    private boolean isConstructorPattern(Function func) {
        // Look for vtable initialization
        InstructionIterator instructions = currentProgram.getListing().getInstructions(func.getBody(), true);
        
        while (instructions.hasNext()) {
            Instruction instr = instructions.next();
            if (instr.getMnemonicString().equals("MOV")) {
                // Look for vtable assignment patterns
                for (int i = 0; i < instr.getNumOperands(); i++) {
                    Object[] opObjects = instr.getOpObjects(i);
                    for (Object obj : opObjects) {
                        if (obj instanceof Address) {
                            Symbol symbol = symbolTable.getPrimarySymbol((Address) obj);
                            if (symbol != null && symbol.getName().contains("vtable")) {
                                return true;
                            }
                        }
                    }
                }
            }
        }
        
        return false;
    }
    
    /**
     * Check if function is a destructor pattern
     */
    private boolean isDestructorPattern(Function func) {
        String funcName = func.getName();
        return funcName.contains("~") || funcName.contains("dtor") || funcName.contains("Destructor");
    }
    
    /**
     * Name constructor function
     */
    private void nameConstructor(Function func) {
        String className = extractClassNameFromFunction(func);
        if (className != null) {
            try {
                int counter = classCounters.getOrDefault(className + "_ctor", 0) + 1;
                classCounters.put(className + "_ctor", counter);
                
                String newName = className + "::" + className;
                if (counter > 1) {
                    newName += "_" + counter;
                }
                
                if (!createdSymbols.contains(newName)) {
                    func.setName(newName, SourceType.ANALYSIS);
                    createdSymbols.add(newName);
                    println("Named constructor: " + newName);
                }
            } catch (Exception e) {
                // Rename failed
            }
        }
    }
    
    /**
     * Name destructor function
     */
    private void nameDestructor(Function func) {
        String className = extractClassNameFromFunction(func);
        if (className != null) {
            try {
                String newName = className + "::~" + className;
                
                if (!createdSymbols.contains(newName)) {
                    func.setName(newName, SourceType.ANALYSIS);
                    createdSymbols.add(newName);
                    println("Named destructor: " + newName);
                }
            } catch (Exception e) {
                // Rename failed
            }
        }
    }
    
    /**
     * Name common virtual functions
     */
    private void nameCommonVirtualFunctions() {
        // This would analyze vtables and name common virtual functions
        // Implementation would be similar to constructor/destructor naming
        println("Virtual function naming not yet implemented");
    }
    
    /**
     * Name vtable symbols
     */
    private void nameVtableSymbols() throws CancelledException {
        println("Naming vtable symbols...");
        
        SymbolIterator symbols = symbolTable.getAllSymbols(true);
        while (symbols.hasNext()) {
            monitor.checkCanceled();
            Symbol symbol = symbols.next();
            String name = symbol.getName();
            
            if (name.contains("vtable") || name.contains("vftable")) {
                improveVtableSymbol(symbol);
            }
        }
    }
    
    /**
     * Improve vtable symbol name
     */
    private void improveVtableSymbol(Symbol symbol) {
        try {
            String className = extractClassNameFromSymbol(symbol.getName());
            String newName = className + "::vtable";
            
            if (!createdSymbols.contains(newName)) {
                symbol.setName(newName, SourceType.ANALYSIS);
                createdSymbols.add(newName);
                println("Renamed vtable: " + symbol.getName() + " -> " + newName);
            }
            
        } catch (Exception e) {
            // Symbol rename failed
        }
    }
    
    /**
     * Clean up generic symbols
     */
    private void cleanupGenericSymbols() throws CancelledException {
        println("Cleaning up generic symbols...");
        
        SymbolIterator symbols = symbolTable.getAllSymbols(true);
        while (symbols.hasNext()) {
            monitor.checkCanceled();
            Symbol symbol = symbols.next();
            String name = symbol.getName();
            
            // Look for generic function names that could be improved
            if (name.startsWith("FUN_") || name.startsWith("SUB_") || name.startsWith("sub_")) {
                Function func = currentProgram.getFunctionManager().getFunctionAt(symbol.getAddress());
                if (func != null && isMFCFunction(func)) {
                    improveMFCFunctionName(func);
                }
            }
        }
    }
    
    /**
     * Extract class name from symbol name
     */
    private String extractClassNameFromSymbol(String symbolName) {
        if (symbolName.contains("::")) {
            return symbolName.substring(0, symbolName.indexOf("::"));
        }
        
        if (symbolName.contains("_")) {
            // Try to extract class name from various patterns
            String[] parts = symbolName.split("_");
            if (parts.length > 0) {
                return parts[0];
            }
        }
        
        return "UnknownClass";
    }
}

