//MFC Message Map Scanner
//Locates and analyzes MFC message map structures in the binary
//@author MFC Analysis Scripts
//@category MFC
//@keybinding 
//@menupath Tools.MFC.Scan Message Maps
//@toolbar 

import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.*;
import ghidra.program.model.data.*;
import ghidra.program.model.listing.*;
import ghidra.program.model.mem.*;
import ghidra.program.model.symbol.*;
import ghidra.util.exception.CancelledException;
import java.util.*;

public class MFCMessageMapScanner extends GhidraScript {
    
    private DataTypeManager dtm;
    private MemoryBlock[] dataBlocks;
    private List<MessageMapInfo> foundMessageMaps;
    private DataType msgMapEntryType;
    private DataType msgMapType;
    
    // Message map information container
    private static class MessageMapInfo {
        Address mapAddress;
        Address entriesAddress;
        List<MessageMapEntry> entries;
        String className;
        
        MessageMapInfo(Address mapAddr, Address entriesAddr) {
            this.mapAddress = mapAddr;
            this.entriesAddress = entriesAddr;
            this.entries = new ArrayList<>();
        }
    }
    
    // Individual message map entry information
    private static class MessageMapEntry {
        long nMessage;
        long nCode;
        long nID;
        long nLastID;
        long nSig;
        Address pfn;
        
        MessageMapEntry(long msg, long code, long id, long lastId, long sig, Address func) {
            this.nMessage = msg;
            this.nCode = code;
            this.nID = id;
            this.nLastID = lastId;
            this.nSig = sig;
            this.pfn = func;
        }
        
        boolean isTerminator() {
            return nMessage == 0 && nCode == 0 && nID == 0 && nLastID == 0 && nSig == 0 && pfn == null;
        }
        
        boolean isValidEntry() {
            // Basic validation checks
            if (isTerminator()) return true;
            
            // Check for valid message IDs
            if (nMessage > 0xFFFF && nMessage != 0xFFFFFFFF) return false;
            
            // Check for reasonable control IDs
            if (nID > 0xFFFF) return false;
            
            // Check signature values
            if (nSig > 100 && nSig < 0x1000) return false; // Likely not a signature
            
            return true;
        }
    }
    
    @Override
    public void run() throws Exception {
        dtm = currentProgram.getDataTypeManager();
        foundMessageMaps = new ArrayList<>();
        
        // Get MFC structure types
        msgMapEntryType = dtm.getDataType(new CategoryPath("/MFC"), "AFX_MSGMAP_ENTRY");
        msgMapType = dtm.getDataType(new CategoryPath("/MFC"), "AFX_MSGMAP");
        
        if (msgMapEntryType == null || msgMapType == null) {
            println("ERROR: MFC structures not found. Please run MFCStructures script first.");
            return;
        }
        
        println("Starting MFC message map scan...");
        
        // Get data sections to scan
        getDataBlocks();
        
        // Scan for message maps
        scanForMessageMaps();
        
        // Analyze found message maps
        analyzeMessageMaps();
        
        // Apply structures and create symbols
        applyStructuresAndSymbols();
        
        println("Message map scan completed!");
        println("Found " + foundMessageMaps.size() + " message maps");
    }
    
    /**
     * Get memory blocks that likely contain data (not code)
     */
    private void getDataBlocks() {
        List<MemoryBlock> blocks = new ArrayList<>();
        
        for (MemoryBlock block : currentProgram.getMemory().getBlocks()) {
            if (block.isRead() && !block.isExecute()) {
                // Likely data section
                blocks.add(block);
                println("Scanning data block: " + block.getName() + 
                       " [" + block.getStart() + " - " + block.getEnd() + "]");
            }
        }
        
        dataBlocks = blocks.toArray(new MemoryBlock[0]);
    }
    
    /**
     * Scan memory for message map patterns
     */
    private void scanForMessageMaps() throws CancelledException {
        int entrySize = msgMapEntryType.getLength();
        
        for (MemoryBlock block : dataBlocks) {
            monitor.setMessage("Scanning " + block.getName());
            
            Address addr = block.getStart();
            Address endAddr = block.getEnd();
            
            while (addr.compareTo(endAddr) < 0) {
                monitor.checkCanceled();
                
                // Look for potential message map entry arrays
                if (isPotentialMessageMapEntries(addr)) {
                    Address entriesAddr = addr;
                    List<MessageMapEntry> entries = parseMessageMapEntries(entriesAddr);
                    
                    if (entries.size() > 1) { // At least one real entry plus terminator
                        // Look for AFX_MSGMAP structure that points to these entries
                        Address mapAddr = findMessageMapStructure(entriesAddr);
                        
                        if (mapAddr != null) {
                            MessageMapInfo mapInfo = new MessageMapInfo(mapAddr, entriesAddr);
                            mapInfo.entries = entries;
                            foundMessageMaps.add(mapInfo);
                            
                            println("Found message map at " + mapAddr + 
                                   " with entries at " + entriesAddr + 
                                   " (" + (entries.size() - 1) + " entries)");
                        }
                    }
                }
                
                addr = addr.add(currentProgram.getDefaultPointerSize());
            }
        }
    }
    
    /**
     * Check if address points to potential message map entries
     */
    private boolean isPotentialMessageMapEntries(Address addr) {
        try {
            int entrySize = msgMapEntryType.getLength();
            
            // Read first entry to check if it looks like a message map entry
            MessageMapEntry entry = readMessageMapEntry(addr);
            if (entry == null || !entry.isValidEntry()) {
                return false;
            }
            
            // Check if there's a terminator entry following
            Address nextAddr = addr.add(entrySize);
            MessageMapEntry nextEntry = readMessageMapEntry(nextAddr);
            
            // Look for either another valid entry or a terminator
            return nextEntry != null && (nextEntry.isValidEntry() || nextEntry.isTerminator());
            
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * Parse message map entries starting at given address
     */
    private List<MessageMapEntry> parseMessageMapEntries(Address addr) {
        List<MessageMapEntry> entries = new ArrayList<>();
        int entrySize = msgMapEntryType.getLength();
        Address currentAddr = addr;
        
        try {
            while (true) {
                MessageMapEntry entry = readMessageMapEntry(currentAddr);
                if (entry == null) break;
                
                entries.add(entry);
                
                if (entry.isTerminator()) {
                    break;
                }
                
                currentAddr = currentAddr.add(entrySize);
                
                // Safety check - don't read too many entries
                if (entries.size() > 1000) {
                    break;
                }
            }
        } catch (Exception e) {
            // Error reading entries
        }
        
        return entries;
    }
    
    /**
     * Read a single message map entry from memory
     */
    private MessageMapEntry readMessageMapEntry(Address addr) {
        try {
            Memory memory = currentProgram.getMemory();
            
            long nMessage = memory.getInt(addr) & 0xFFFFFFFFL;
            long nCode = memory.getInt(addr.add(4)) & 0xFFFFFFFFL;
            long nID = memory.getInt(addr.add(8)) & 0xFFFFFFFFL;
            long nLastID = memory.getInt(addr.add(12)) & 0xFFFFFFFFL;
            
            long nSig;
            Address pfn;
            
            if (currentProgram.getDefaultPointerSize() == 8) {
                // 64-bit
                nSig = memory.getLong(addr.add(16));
                long pfnValue = memory.getLong(addr.add(24));
                pfn = pfnValue != 0 ? currentProgram.getAddressFactory().getDefaultAddressSpace().getAddress(pfnValue) : null;
            } else {
                // 32-bit
                nSig = memory.getInt(addr.add(16)) & 0xFFFFFFFFL;
                long pfnValue = memory.getInt(addr.add(20)) & 0xFFFFFFFFL;
                pfn = pfnValue != 0 ? currentProgram.getAddressFactory().getDefaultAddressSpace().getAddress(pfnValue) : null;
            }
            
            return new MessageMapEntry(nMessage, nCode, nID, nLastID, nSig, pfn);
            
        } catch (Exception e) {
            return null;
        }
    }
    
    /**
     * Find AFX_MSGMAP structure that points to the given entries
     */
    private Address findMessageMapStructure(Address entriesAddr) {
        // Search backwards and forwards for a structure that points to entriesAddr
        int ptrSize = currentProgram.getDefaultPointerSize();
        
        for (MemoryBlock block : dataBlocks) {
            Address addr = block.getStart();
            Address endAddr = block.getEnd();
            
            while (addr.compareTo(endAddr.subtract(ptrSize * 2)) <= 0) {
                try {
                    Memory memory = currentProgram.getMemory();
                    
                    // Read potential AFX_MSGMAP structure
                    long baseMapPtr = ptrSize == 8 ? memory.getLong(addr) : memory.getInt(addr) & 0xFFFFFFFFL;
                    long entriesPtr = ptrSize == 8 ? memory.getLong(addr.add(ptrSize)) : memory.getInt(addr.add(ptrSize)) & 0xFFFFFFFFL;
                    
                    if (entriesPtr == entriesAddr.getOffset()) {
                        return addr;
                    }
                    
                } catch (Exception e) {
                    // Continue searching
                }
                
                addr = addr.add(ptrSize);
            }
        }
        
        return null;
    }
    
    /**
     * Analyze found message maps to extract additional information
     */
    private void analyzeMessageMaps() {
        for (MessageMapInfo mapInfo : foundMessageMaps) {
            analyzeMessageMap(mapInfo);
        }
    }
    
    /**
     * Analyze a single message map
     */
    private void analyzeMessageMap(MessageMapInfo mapInfo) {
        // Try to determine class name from nearby symbols or references
        mapInfo.className = findClassName(mapInfo.mapAddress);
        
        // Analyze each entry
        for (MessageMapEntry entry : mapInfo.entries) {
            if (!entry.isTerminator() && entry.pfn != null) {
                analyzeMessageHandler(entry);
            }
        }
    }
    
    /**
     * Try to find the class name associated with a message map
     */
    private String findClassName(Address mapAddr) {
        // Look for symbols near the message map
        SymbolTable symbolTable = currentProgram.getSymbolTable();
        
        // Check for symbols at or near the message map address
        Symbol[] symbols = symbolTable.getSymbols(mapAddr);
        for (Symbol symbol : symbols) {
            String name = symbol.getName();
            if (name.contains("messageMap") || name.contains("MessageMap")) {
                // Extract class name from symbol
                return extractClassNameFromSymbol(name);
            }
        }
        
        // Look for references to this message map
        ReferenceManager refMgr = currentProgram.getReferenceManager();
        ReferenceIterator refs = refMgr.getReferencesTo(mapAddr);
        
        while (refs.hasNext()) {
            Reference ref = refs.next();
            Address fromAddr = ref.getFromAddress();
            
            // Look for symbols near the reference
            symbols = symbolTable.getSymbols(fromAddr);
            for (Symbol symbol : symbols) {
                String name = symbol.getName();
                if (name.contains("::") || name.contains("GetMessageMap")) {
                    return extractClassNameFromSymbol(name);
                }
            }
        }
        
        return "UnknownClass_" + mapAddr.toString();
    }
    
    /**
     * Extract class name from symbol name
     */
    private String extractClassNameFromSymbol(String symbolName) {
        // Handle various naming patterns
        if (symbolName.contains("::")) {
            return symbolName.substring(0, symbolName.indexOf("::"));
        }
        
        if (symbolName.startsWith("_") && symbolName.contains("messageMap")) {
            // Extract from mangled name
            int start = symbolName.indexOf("_") + 1;
            int end = symbolName.indexOf("messageMap");
            if (end > start) {
                return symbolName.substring(start, end);
            }
        }
        
        return symbolName;
    }
    
    /**
     * Analyze a message handler function
     */
    private void analyzeMessageHandler(MessageMapEntry entry) {
        if (entry.pfn == null) return;
        
        // Create function if it doesn't exist
        Function func = currentProgram.getFunctionManager().getFunctionAt(entry.pfn);
        if (func == null) {
            try {
                func = createFunction(entry.pfn);
            } catch (Exception e) {
                // Function creation failed
                return;
            }
        }
        
        // Add comment describing the message mapping
        String comment = buildMessageComment(entry);
        func.setComment(comment);
    }
    
    /**
     * Build descriptive comment for message handler
     */
    private String buildMessageComment(MessageMapEntry entry) {
        StringBuilder comment = new StringBuilder();
        comment.append("MFC Message Handler\\n");
        
        // Decode message type
        if (entry.nMessage == 0x0111) { // WM_COMMAND
            comment.append("Message: WM_COMMAND\\n");
            if (entry.nCode == 0) {
                comment.append("Type: Menu/Accelerator Command\\n");
                comment.append("Command ID: ").append(entry.nID).append("\\n");
            } else {
                comment.append("Type: Control Notification\\n");
                comment.append("Notification Code: ").append(entry.nCode).append("\\n");
                comment.append("Control ID: ").append(entry.nID).append("\\n");
            }
        } else if (entry.nMessage == 0xFFFFFFFF) {
            comment.append("Message: UPDATE_COMMAND_UI\\n");
            comment.append("Command ID: ").append(entry.nID).append("\\n");
        } else {
            comment.append("Message: 0x").append(Long.toHexString(entry.nMessage)).append("\\n");
        }
        
        comment.append("Signature: ").append(entry.nSig);
        
        return comment.toString();
    }
    
    /**
     * Apply structures and create symbols for found message maps
     */
    private void applyStructuresAndSymbols() throws Exception {
        for (MessageMapInfo mapInfo : foundMessageMaps) {
            applyMessageMapStructures(mapInfo);
            createMessageMapSymbols(mapInfo);
        }
    }
    
    /**
     * Apply MFC structures to a message map
     */
    private void applyMessageMapStructures(MessageMapInfo mapInfo) {
        try {
            // Apply AFX_MSGMAP structure
            createData(mapInfo.mapAddress, msgMapType);
            
            // Apply AFX_MSGMAP_ENTRY array
            int entryCount = mapInfo.entries.size();
            ArrayDataType entryArray = new ArrayDataType(msgMapEntryType, entryCount, msgMapEntryType.getLength());
            createData(mapInfo.entriesAddress, entryArray);
            
        } catch (Exception e) {
            println("Warning: Could not apply structures at " + mapInfo.mapAddress + ": " + e.getMessage());
        }
    }
    
    /**
     * Create symbols for message map components
     */
    private void createMessageMapSymbols(MessageMapInfo mapInfo) {
        try {
            SymbolTable symbolTable = currentProgram.getSymbolTable();
            
            // Create symbol for message map
            String mapSymbol = mapInfo.className + "_messageMap";
            symbolTable.createLabel(mapInfo.mapAddress, mapSymbol, SourceType.ANALYSIS);
            
            // Create symbol for entries array
            String entriesSymbol = mapInfo.className + "_messageEntries";
            symbolTable.createLabel(mapInfo.entriesAddress, entriesSymbol, SourceType.ANALYSIS);
            
            // Create symbols for handler functions
            int handlerIndex = 0;
            for (MessageMapEntry entry : mapInfo.entries) {
                if (!entry.isTerminator() && entry.pfn != null) {
                    String handlerSymbol = mapInfo.className + "_Handler_" + handlerIndex;
                    try {
                        symbolTable.createLabel(entry.pfn, handlerSymbol, SourceType.ANALYSIS);
                    } catch (Exception e) {
                        // Symbol might already exist
                    }
                    handlerIndex++;
                }
            }
            
        } catch (Exception e) {
            println("Warning: Could not create symbols for " + mapInfo.className + ": " + e.getMessage());
        }
    }
}

