//MFC Class Hierarchy Analyzer
//Reconstructs MFC class inheritance relationships and identifies class boundaries
//@author MFC Analysis Scripts
//@category MFC
//@keybinding 
//@menupath Tools.MFC.Analyze Class Hierarchy
//@toolbar 

import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.*;
import ghidra.program.model.data.*;
import ghidra.program.model.listing.*;
import ghidra.program.model.mem.*;
import ghidra.program.model.symbol.*;
import ghidra.util.exception.CancelledException;
import java.util.*;

public class MFCClassAnalyzer extends GhidraScript {
    
    private Map<String, MFCClassInfo> discoveredClasses;
    private Map<Address, String> vtableToClass;
    private List<Address> messageMapAddresses;
    
    // MFC Class information container
    private static class MFCClassInfo {
        String className;
        String baseClassName;
        Address messageMapAddress;
        Address vtableAddress;
        List<Address> constructors;
        List<Address> destructors;
        List<Address> memberFunctions;
        Set<String> handledMessages;
        
        MFCClassInfo(String name) {
            this.className = name;
            this.constructors = new ArrayList<>();
            this.destructors = new ArrayList<>();
            this.memberFunctions = new ArrayList<>();
            this.handledMessages = new HashSet<>();
        }
    }
    
    @Override
    public void run() throws Exception {
        discoveredClasses = new HashMap<>();
        vtableToClass = new HashMap<>();
        messageMapAddresses = new ArrayList<>();
        
        println("Starting MFC class hierarchy analysis...");
        
        // Step 1: Find all message maps (should be run after MFCMessageMapScanner)
        findMessageMaps();
        
        // Step 2: Analyze message map inheritance chains
        analyzeMessageMapInheritance();
        
        // Step 3: Find and analyze vtables
        findAndAnalyzeVtables();
        
        // Step 4: Identify constructors and destructors
        identifyConstructorsDestructors();
        
        // Step 5: Map member functions to classes
        mapMemberFunctions();
        
        // Step 6: Create class hierarchy visualization
        createClassHierarchy();
        
        // Step 7: Apply analysis results
        applyClassAnalysis();
        
        println("Class hierarchy analysis completed!");
        println("Discovered " + discoveredClasses.size() + " MFC classes");
    }
    
    /**
     * Find all message maps in the program
     */
    private void findMessageMaps() {
        SymbolTable symbolTable = currentProgram.getSymbolTable();
        
        // Look for message map symbols
        SymbolIterator symbols = symbolTable.getAllSymbols(true);
        while (symbols.hasNext()) {
            Symbol symbol = symbols.next();
            String name = symbol.getName();
            
            if (name.contains("messageMap") || name.contains("MessageMap")) {
                messageMapAddresses.add(symbol.getAddress());
                println("Found message map: " + name + " at " + symbol.getAddress());
            }
        }
        
        // Also look for AFX_MSGMAP structures
        DataTypeManager dtm = currentProgram.getDataTypeManager();
        DataType msgMapType = dtm.getDataType(new CategoryPath("/MFC"), "AFX_MSGMAP");
        
        if (msgMapType != null) {
            // Find all instances of AFX_MSGMAP
            AddressSetView dataAddresses = currentProgram.getMemory().getLoadedAndInitializedAddressSet();
            AddressIterator addresses = dataAddresses.getAddresses(true);
            
            while (addresses.hasNext()) {
                Address addr = addresses.next();
                Data data = currentProgram.getListing().getDataAt(addr);
                
                if (data != null && data.getDataType().equals(msgMapType)) {
                    if (!messageMapAddresses.contains(addr)) {
                        messageMapAddresses.add(addr);
                        println("Found AFX_MSGMAP structure at " + addr);
                    }
                }
            }
        }
    }
    
    /**
     * Analyze message map inheritance chains to build class hierarchy
     */
    private void analyzeMessageMapInheritance() throws CancelledException {
        for (Address mapAddr : messageMapAddresses) {
            monitor.checkCanceled();
            analyzeMessageMapChain(mapAddr);
        }
    }
    
    /**
     * Analyze a single message map and its inheritance chain
     */
    private void analyzeMessageMapChain(Address mapAddr) {
        try {
            Memory memory = currentProgram.getMemory();
            int ptrSize = currentProgram.getDefaultPointerSize();
            
            // Read AFX_MSGMAP structure
            long baseMapPtr = ptrSize == 8 ? memory.getLong(mapAddr) : memory.getInt(mapAddr) & 0xFFFFFFFFL;
            long entriesPtr = ptrSize == 8 ? memory.getLong(mapAddr.add(ptrSize)) : memory.getInt(mapAddr.add(ptrSize)) & 0xFFFFFFFFL;
            
            // Get class name from symbols or nearby references
            String className = findClassNameForMessageMap(mapAddr);
            
            MFCClassInfo classInfo = discoveredClasses.get(className);
            if (classInfo == null) {
                classInfo = new MFCClassInfo(className);
                discoveredClasses.put(className, classInfo);
            }
            
            classInfo.messageMapAddress = mapAddr;
            
            // If there's a base message map, find the base class
            if (baseMapPtr != 0) {
                Address baseMapAddr = currentProgram.getAddressFactory().getDefaultAddressSpace().getAddress(baseMapPtr);
                String baseClassName = findClassNameForMessageMap(baseMapAddr);
                classInfo.baseClassName = baseClassName;
                
                println("Found inheritance: " + className + " extends " + baseClassName);
            }
            
            // Analyze message handlers in this map
            if (entriesPtr != 0) {
                analyzeMessageHandlers(classInfo, entriesPtr);
            }
            
        } catch (Exception e) {
            println("Error analyzing message map at " + mapAddr + ": " + e.getMessage());
        }
    }
    
    /**
     * Find class name associated with a message map
     */
    private String findClassNameForMessageMap(Address mapAddr) {
        SymbolTable symbolTable = currentProgram.getSymbolTable();
        
        // Check direct symbols
        Symbol[] symbols = symbolTable.getSymbols(mapAddr);
        for (Symbol symbol : symbols) {
            String name = symbol.getName();
            if (name.contains("messageMap")) {
                return extractClassNameFromSymbol(name);
            }
        }
        
        // Look for references to this address
        ReferenceManager refMgr = currentProgram.getReferenceManager();
        ReferenceIterator refs = refMgr.getReferencesTo(mapAddr);
        
        while (refs.hasNext()) {
            Reference ref = refs.next();
            Address fromAddr = ref.getFromAddress();
            
            // Look for GetMessageMap function
            Function func = currentProgram.getFunctionManager().getFunctionContaining(fromAddr);
            if (func != null) {
                String funcName = func.getName();
                if (funcName.contains("GetMessageMap")) {
                    return extractClassNameFromSymbol(funcName);
                }
            }
            
            // Look for symbols near the reference
            symbols = symbolTable.getSymbols(fromAddr);
            for (Symbol symbol : symbols) {
                String name = symbol.getName();
                if (name.contains("::") || name.contains("GetMessageMap")) {
                    return extractClassNameFromSymbol(name);
                }
            }
        }
        
        return "UnknownClass_" + mapAddr.toString();
    }
    
    /**
     * Extract class name from symbol name
     */
    private String extractClassNameFromSymbol(String symbolName) {
        // Handle C++ mangled names and various patterns
        if (symbolName.contains("::")) {
            return symbolName.substring(0, symbolName.indexOf("::"));
        }
        
        if (symbolName.contains("GetMessageMap")) {
            // Pattern: ClassName_GetMessageMap or similar
            int end = symbolName.indexOf("GetMessageMap");
            if (end > 0) {
                String prefix = symbolName.substring(0, end);
                return prefix.replaceAll("_+$", ""); // Remove trailing underscores
            }
        }
        
        if (symbolName.contains("messageMap")) {
            int end = symbolName.indexOf("messageMap");
            if (end > 0) {
                String prefix = symbolName.substring(0, end);
                return prefix.replaceAll("_+$", "");
            }
        }
        
        // Try to extract from mangled names
        if (symbolName.startsWith("?")) {
            // MSVC mangled name
            return demangledClassName(symbolName);
        }
        
        return symbolName;
    }
    
    /**
     * Simple demangling for class names (basic implementation)
     */
    private String demangledClassName(String mangledName) {
        // This is a simplified demangler - in practice, you'd want a full demangler
        // Look for patterns like ?GetMessageMap@ClassName@@
        if (mangledName.contains("@") && mangledName.contains("@@")) {
            int start = mangledName.indexOf("@") + 1;
            int end = mangledName.indexOf("@@", start);
            if (end > start) {
                return mangledName.substring(start, end);
            }
        }
        
        return mangledName;
    }
    
    /**
     * Analyze message handlers for a class
     */
    private void analyzeMessageHandlers(MFCClassInfo classInfo, long entriesPtr) {
        try {
            Address entriesAddr = currentProgram.getAddressFactory().getDefaultAddressSpace().getAddress(entriesPtr);
            Memory memory = currentProgram.getMemory();
            
            DataTypeManager dtm = currentProgram.getDataTypeManager();
            DataType entryType = dtm.getDataType(new CategoryPath("/MFC"), "AFX_MSGMAP_ENTRY");
            if (entryType == null) return;
            
            int entrySize = entryType.getLength();
            Address currentAddr = entriesAddr;
            
            while (true) {
                // Read message map entry
                long nMessage = memory.getInt(currentAddr) & 0xFFFFFFFFL;
                long nCode = memory.getInt(currentAddr.add(4)) & 0xFFFFFFFFL;
                long nID = memory.getInt(currentAddr.add(8)) & 0xFFFFFFFFL;
                
                // Check for terminator
                if (nMessage == 0 && nCode == 0 && nID == 0) {
                    break;
                }
                
                // Get function pointer
                Address pfnAddr;
                if (currentProgram.getDefaultPointerSize() == 8) {
                    long pfnValue = memory.getLong(currentAddr.add(24));
                    pfnAddr = pfnValue != 0 ? currentProgram.getAddressFactory().getDefaultAddressSpace().getAddress(pfnValue) : null;
                } else {
                    long pfnValue = memory.getInt(currentAddr.add(20)) & 0xFFFFFFFFL;
                    pfnAddr = pfnValue != 0 ? currentProgram.getAddressFactory().getDefaultAddressSpace().getAddress(pfnValue) : null;
                }
                
                if (pfnAddr != null) {
                    classInfo.memberFunctions.add(pfnAddr);
                    
                    // Record handled message
                    String messageDesc = getMessageDescription(nMessage, nCode, nID);
                    classInfo.handledMessages.add(messageDesc);
                }
                
                currentAddr = currentAddr.add(entrySize);
            }
            
        } catch (Exception e) {
            println("Error analyzing message handlers: " + e.getMessage());
        }
    }
    
    /**
     * Get description of a message
     */
    private String getMessageDescription(long nMessage, long nCode, long nID) {
        if (nMessage == 0x0111) { // WM_COMMAND
            if (nCode == 0) {
                return "Command_" + nID;
            } else {
                return "Notification_" + nCode + "_" + nID;
            }
        } else if (nMessage == 0xFFFFFFFF) {
            return "UpdateUI_" + nID;
        } else {
            return "Message_0x" + Long.toHexString(nMessage);
        }
    }
    
    /**
     * Find and analyze virtual function tables
     */
    private void findAndAnalyzeVtables() throws CancelledException {
        println("Searching for vtables...");
        
        // Look for vtable patterns in data sections
        for (MemoryBlock block : currentProgram.getMemory().getBlocks()) {
            if (block.isRead() && !block.isExecute()) {
                monitor.setMessage("Scanning " + block.getName() + " for vtables");
                scanBlockForVtables(block);
            }
        }
    }
    
    /**
     * Scan a memory block for vtable patterns
     */
    private void scanBlockForVtables(MemoryBlock block) throws CancelledException {
        Address addr = block.getStart();
        Address endAddr = block.getEnd();
        int ptrSize = currentProgram.getDefaultPointerSize();
        
        while (addr.compareTo(endAddr.subtract(ptrSize * 4)) <= 0) {
            monitor.checkCanceled();
            
            if (isPotentialVtable(addr)) {
                analyzeVtable(addr);
            }
            
            addr = addr.add(ptrSize);
        }
    }
    
    /**
     * Check if address points to a potential vtable
     */
    private boolean isPotentialVtable(Address addr) {
        try {
            Memory memory = currentProgram.getMemory();
            int ptrSize = currentProgram.getDefaultPointerSize();
            
            // Read several consecutive pointers
            for (int i = 0; i < 4; i++) {
                long ptrValue = ptrSize == 8 ? memory.getLong(addr.add(i * ptrSize)) : memory.getInt(addr.add(i * ptrSize)) & 0xFFFFFFFFL;
                
                if (ptrValue == 0) continue; // NULL pointers are OK in vtables
                
                Address targetAddr = currentProgram.getAddressFactory().getDefaultAddressSpace().getAddress(ptrValue);
                
                // Check if pointer points to executable memory
                MemoryBlock targetBlock = currentProgram.getMemory().getBlock(targetAddr);
                if (targetBlock == null || !targetBlock.isExecute()) {
                    return false;
                }
                
                // Check if it points to a function
                Function func = currentProgram.getFunctionManager().getFunctionAt(targetAddr);
                if (func == null) {
                    // Try to create function
                    try {
                        Instruction instr = currentProgram.getListing().getInstructionAt(targetAddr);
                        if (instr == null) {
                            return false;
                        }
                    } catch (Exception e) {
                        return false;
                    }
                }
            }
            
            return true;
            
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * Analyze a vtable and try to associate it with a class
     */
    private void analyzeVtable(Address vtableAddr) {
        try {
            // Look for references to this vtable
            ReferenceManager refMgr = currentProgram.getReferenceManager();
            ReferenceIterator refs = refMgr.getReferencesTo(vtableAddr);
            
            String className = null;
            
            while (refs.hasNext()) {
                Reference ref = refs.next();
                Address fromAddr = ref.getFromAddress();
                
                // Look for constructor patterns
                Function func = currentProgram.getFunctionManager().getFunctionContaining(fromAddr);
                if (func != null) {
                    String funcName = func.getName();
                    
                    // Check if this looks like a constructor
                    if (isConstructorPattern(func, vtableAddr)) {
                        className = extractClassNameFromConstructor(funcName);
                        break;
                    }
                }
            }
            
            if (className != null) {
                MFCClassInfo classInfo = discoveredClasses.get(className);
                if (classInfo == null) {
                    classInfo = new MFCClassInfo(className);
                    discoveredClasses.put(className, classInfo);
                }
                
                classInfo.vtableAddress = vtableAddr;
                vtableToClass.put(vtableAddr, className);
                
                println("Found vtable for " + className + " at " + vtableAddr);
            }
            
        } catch (Exception e) {
            // Error analyzing vtable
        }
    }
    
    /**
     * Check if function contains constructor patterns
     */
    private boolean isConstructorPattern(Function func, Address vtableAddr) {
        // Look for vtable assignment in the function
        InstructionIterator instructions = currentProgram.getListing().getInstructions(func.getBody(), true);
        
        while (instructions.hasNext()) {
            Instruction instr = instructions.next();
            
            // Look for MOV instructions that reference the vtable
            if (instr.getMnemonicString().equals("MOV")) {
                for (int i = 0; i < instr.getNumOperands(); i++) {
                    Object[] opObjects = instr.getOpObjects(i);
                    for (Object obj : opObjects) {
                        if (obj instanceof Address && ((Address) obj).equals(vtableAddr)) {
                            return true;
                        }
                    }
                }
            }
        }
        
        return false;
    }
    
    /**
     * Extract class name from constructor function name
     */
    private String extractClassNameFromConstructor(String funcName) {
        // Handle various constructor naming patterns
        if (funcName.contains("::")) {
            return funcName.substring(0, funcName.indexOf("::"));
        }
        
        if (funcName.contains("_ctor") || funcName.contains("Constructor")) {
            int end = funcName.indexOf("_ctor");
            if (end == -1) end = funcName.indexOf("Constructor");
            return funcName.substring(0, end);
        }
        
        return funcName;
    }
    
    /**
     * Identify constructors and destructors
     */
    private void identifyConstructorsDestructors() {
        FunctionManager funcMgr = currentProgram.getFunctionManager();
        FunctionIterator functions = funcMgr.getFunctions(true);
        
        while (functions.hasNext()) {
            Function func = functions.next();
            String funcName = func.getName();
            
            // Look for constructor/destructor patterns
            if (isConstructorName(funcName)) {
                String className = extractClassNameFromConstructor(funcName);
                MFCClassInfo classInfo = getOrCreateClassInfo(className);
                classInfo.constructors.add(func.getEntryPoint());
            } else if (isDestructorName(funcName)) {
                String className = extractClassNameFromDestructor(funcName);
                MFCClassInfo classInfo = getOrCreateClassInfo(className);
                classInfo.destructors.add(func.getEntryPoint());
            }
        }
    }
    
    /**
     * Check if function name indicates a constructor
     */
    private boolean isConstructorName(String name) {
        return name.contains("_ctor") || name.contains("Constructor") || 
               (name.contains("::") && name.substring(name.lastIndexOf("::") + 2).equals(name.substring(0, name.indexOf("::"))));
    }
    
    /**
     * Check if function name indicates a destructor
     */
    private boolean isDestructorName(String name) {
        return name.contains("_dtor") || name.contains("Destructor") || name.contains("~");
    }
    
    /**
     * Extract class name from destructor function name
     */
    private String extractClassNameFromDestructor(String funcName) {
        if (funcName.contains("~")) {
            int start = funcName.indexOf("~") + 1;
            int end = funcName.indexOf("::", start);
            if (end == -1) end = funcName.length();
            return funcName.substring(start, end);
        }
        
        return extractClassNameFromConstructor(funcName);
    }
    
    /**
     * Get or create class info
     */
    private MFCClassInfo getOrCreateClassInfo(String className) {
        MFCClassInfo classInfo = discoveredClasses.get(className);
        if (classInfo == null) {
            classInfo = new MFCClassInfo(className);
            discoveredClasses.put(className, classInfo);
        }
        return classInfo;
    }
    
    /**
     * Map member functions to classes
     */
    private void mapMemberFunctions() {
        // This is already partially done in analyzeMessageHandlers
        // Here we can add additional heuristics to identify more member functions
        
        for (MFCClassInfo classInfo : discoveredClasses.values()) {
            if (classInfo.vtableAddress != null) {
                extractVtableFunctions(classInfo);
            }
        }
    }
    
    /**
     * Extract virtual functions from vtable
     */
    private void extractVtableFunctions(MFCClassInfo classInfo) {
        try {
            Memory memory = currentProgram.getMemory();
            int ptrSize = currentProgram.getDefaultPointerSize();
            Address vtableAddr = classInfo.vtableAddress;
            
            // Read virtual function pointers
            for (int i = 0; i < 20; i++) { // Limit to reasonable number
                Address ptrAddr = vtableAddr.add(i * ptrSize);
                long funcPtr = ptrSize == 8 ? memory.getLong(ptrAddr) : memory.getInt(ptrAddr) & 0xFFFFFFFFL;
                
                if (funcPtr == 0) continue;
                
                Address funcAddr = currentProgram.getAddressFactory().getDefaultAddressSpace().getAddress(funcPtr);
                
                // Verify it's a valid function
                Function func = currentProgram.getFunctionManager().getFunctionAt(funcAddr);
                if (func != null) {
                    if (!classInfo.memberFunctions.contains(funcAddr)) {
                        classInfo.memberFunctions.add(funcAddr);
                    }
                }
            }
            
        } catch (Exception e) {
            // Error reading vtable
        }
    }
    
    /**
     * Create class hierarchy visualization
     */
    private void createClassHierarchy() {
        println("\\n=== MFC Class Hierarchy ===");
        
        // Find root classes (no base class)
        Set<String> rootClasses = new HashSet<>();
        for (MFCClassInfo classInfo : discoveredClasses.values()) {
            if (classInfo.baseClassName == null || !discoveredClasses.containsKey(classInfo.baseClassName)) {
                rootClasses.add(classInfo.className);
            }
        }
        
        // Print hierarchy starting from root classes
        for (String rootClass : rootClasses) {
            printClassHierarchy(rootClass, 0);
        }
    }
    
    /**
     * Print class hierarchy recursively
     */
    private void printClassHierarchy(String className, int depth) {
        MFCClassInfo classInfo = discoveredClasses.get(className);
        if (classInfo == null) return;
        
        // Print indentation
        StringBuilder indent = new StringBuilder();
        for (int i = 0; i < depth; i++) {
            indent.append("  ");
        }
        
        println(indent + className + " (" + classInfo.memberFunctions.size() + " methods, " + 
                classInfo.handledMessages.size() + " messages)");
        
        // Print child classes
        for (MFCClassInfo childInfo : discoveredClasses.values()) {
            if (className.equals(childInfo.baseClassName)) {
                printClassHierarchy(childInfo.className, depth + 1);
            }
        }
    }
    
    /**
     * Apply class analysis results to Ghidra
     */
    private void applyClassAnalysis() throws Exception {
        SymbolTable symbolTable = currentProgram.getSymbolTable();
        
        for (MFCClassInfo classInfo : discoveredClasses.values()) {
            // Create namespace for the class
            Namespace classNamespace = createClassNamespace(classInfo.className);
            
            // Label member functions
            for (Address funcAddr : classInfo.memberFunctions) {
                Function func = currentProgram.getFunctionManager().getFunctionAt(funcAddr);
                if (func != null) {
                    try {
                        // Move function to class namespace
                        func.setParentNamespace(classNamespace);
                    } catch (Exception e) {
                        // Function might already be in namespace
                    }
                }
            }
            
            // Label vtable
            if (classInfo.vtableAddress != null) {
                try {
                    symbolTable.createLabel(classInfo.vtableAddress, classInfo.className + "_vtable", 
                                          classNamespace, SourceType.ANALYSIS);
                } catch (Exception e) {
                    // Symbol might already exist
                }
            }
        }
    }
    
    /**
     * Create namespace for a class
     */
    private Namespace createClassNamespace(String className) throws Exception {
        SymbolTable symbolTable = currentProgram.getSymbolTable();
        
        try {
            return symbolTable.createNameSpace(currentProgram.getGlobalNamespace(), className, SourceType.ANALYSIS);
        } catch (Exception e) {
            // Namespace might already exist
            return symbolTable.getNamespace(className, currentProgram.getGlobalNamespace());
        }
    }
}

