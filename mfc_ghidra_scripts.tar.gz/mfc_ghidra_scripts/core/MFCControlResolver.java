//MFC Control ID Resolver
//Resolves control IDs to actual UI elements and resources
//@author MFC Analysis Scripts
//@category MFC
//@keybinding 
//@menupath Tools.MFC.Resolve Control IDs
//@toolbar 

import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.*;
import ghidra.program.model.data.*;
import ghidra.program.model.listing.*;
import ghidra.program.model.mem.*;
import ghidra.program.model.symbol.*;
import ghidra.util.exception.CancelledException;
import java.util.*;

public class MFCControlResolver extends GhidraScript {
    
    private Map<Long, ControlInfo> controlMappings;
    private Map<Long, String> menuMappings;
    private Map<Long, String> stringMappings;
    private List<DialogInfo> dialogLayouts;
    private MemoryBlock resourceBlock;
    
    // Control information
    private static class ControlInfo {
        long controlId;
        String controlType;
        String controlText;
        String dialogName;
        int x, y, width, height;
        long style;
        
        ControlInfo(long id) {
            this.controlId = id;
        }
        
        @Override
        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("ID ").append(controlId);
            if (controlType != null) sb.append(" (").append(controlType).append(")");
            if (controlText != null) sb.append(" \"").append(controlText).append("\"");
            if (dialogName != null) sb.append(" in ").append(dialogName);
            return sb.toString();
        }
    }
    
    // Dialog information
    private static class DialogInfo {
        String dialogName;
        long dialogId;
        List<ControlInfo> controls;
        int x, y, width, height;
        
        DialogInfo(String name, long id) {
            this.dialogName = name;
            this.dialogId = id;
            this.controls = new ArrayList<>();
        }
    }
    
    @Override
    public void run() throws Exception {
        controlMappings = new HashMap<>();
        menuMappings = new HashMap<>();
        stringMappings = new HashMap<>();
        dialogLayouts = new ArrayList<>();
        
        println("Starting MFC control ID resolution...");
        
        // Step 1: Find resource section
        findResourceSection();
        
        // Step 2: Parse string table resources
        parseStringTable();
        
        // Step 3: Parse dialog resources
        parseDialogResources();
        
        // Step 4: Parse menu resources
        parseMenuResources();
        
        // Step 5: Analyze control ID usage in code
        analyzeControlUsage();
        
        // Step 6: Create symbols and comments
        createControlSymbols();
        
        // Step 7: Generate control mapping report
        generateControlReport();
        
        println("Control ID resolution completed!");
        println("Resolved " + controlMappings.size() + " control IDs");
    }
    
    /**
     * Find the resource section (.rsrc)
     */
    private void findResourceSection() {
        for (MemoryBlock block : currentProgram.getMemory().getBlocks()) {
            String name = block.getName().toLowerCase();
            if (name.contains("rsrc") || name.contains("resource")) {
                resourceBlock = block;
                println("Found resource section: " + block.getName() + 
                       " [" + block.getStart() + " - " + block.getEnd() + "]");
                return;
            }
        }
        
        println("Warning: No resource section found. Control ID resolution will be limited.");
    }
    
    /**
     * Parse string table resources
     */
    private void parseStringTable() throws CancelledException {
        if (resourceBlock == null) return;
        
        println("Parsing string table resources...");
        
        try {
            // Look for string table patterns in the resource section
            Address addr = resourceBlock.getStart();
            Address endAddr = resourceBlock.getEnd();
            Memory memory = currentProgram.getMemory();
            
            while (addr.compareTo(endAddr) < 0) {
                monitor.checkCanceled();
                
                // Look for potential string table entries
                if (isPotentialStringEntry(addr)) {
                    parseStringEntry(addr);
                }
                
                addr = addr.add(1);
            }
            
        } catch (Exception e) {
            println("Error parsing string table: " + e.getMessage());
        }
    }
    
    /**
     * Check if address points to a potential string entry
     */
    private boolean isPotentialStringEntry(Address addr) {
        try {
            Memory memory = currentProgram.getMemory();
            
            // Read potential string length
            int length = memory.getShort(addr) & 0xFFFF;
            
            // Reasonable string length check
            if (length == 0 || length > 1000) return false;
            
            // Check if followed by readable string data
            for (int i = 0; i < Math.min(length, 20); i++) {
                byte b = memory.getByte(addr.add(2 + i * 2)); // Unicode strings
                if (b == 0 && i > 0) continue; // Null terminator is OK
                if (b < 32 || b > 126) return false; // Non-printable character
            }
            
            return true;
            
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * Parse a string entry
     */
    private void parseStringEntry(Address addr) {
        try {
            Memory memory = currentProgram.getMemory();
            
            // Read string length
            int length = memory.getShort(addr) & 0xFFFF;
            if (length == 0) return;
            
            // Read Unicode string
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < length; i++) {
                char c = (char)(memory.getShort(addr.add(2 + i * 2)) & 0xFFFF);
                if (c == 0) break;
                sb.append(c);
            }
            
            String text = sb.toString();
            if (text.length() > 0) {
                // Try to determine the string ID (this is simplified)
                long stringId = addr.getOffset() % 0x10000; // Simplified ID calculation
                stringMappings.put(stringId, text);
            }
            
        } catch (Exception e) {
            // Error parsing string
        }
    }
    
    /**
     * Parse dialog resources
     */
    private void parseDialogResources() throws CancelledException {
        if (resourceBlock == null) return;
        
        println("Parsing dialog resources...");
        
        try {
            // Look for dialog template patterns
            Address addr = resourceBlock.getStart();
            Address endAddr = resourceBlock.getEnd();
            
            while (addr.compareTo(endAddr.subtract(32)) < 0) {
                monitor.checkCanceled();
                
                if (isPotentialDialogTemplate(addr)) {
                    parseDialogTemplate(addr);
                }
                
                addr = addr.add(4); // Align to DWORD boundaries
            }
            
        } catch (Exception e) {
            println("Error parsing dialog resources: " + e.getMessage());
        }
    }
    
    /**
     * Check if address points to a potential dialog template
     */
    private boolean isPotentialDialogTemplate(Address addr) {
        try {
            Memory memory = currentProgram.getMemory();
            
            // Read potential DLGTEMPLATE structure
            long style = memory.getInt(addr) & 0xFFFFFFFFL;
            long exStyle = memory.getInt(addr.add(4)) & 0xFFFFFFFFL;
            int cdit = memory.getShort(addr.add(8)) & 0xFFFF; // Number of controls
            
            // Basic validation
            if (cdit > 1000 || cdit < 0) return false; // Unreasonable control count
            
            // Check for common dialog styles
            long DS_SETFONT = 0x40L;
            long DS_MODALFRAME = 0x80L;
            long WS_POPUP = 0x80000000L;
            long WS_CAPTION = 0x00C00000L;
            
            // Should have some common dialog style bits
            return (style & (DS_SETFONT | DS_MODALFRAME | WS_POPUP | WS_CAPTION)) != 0;
            
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * Parse a dialog template
     */
    private void parseDialogTemplate(Address addr) {
        try {
            Memory memory = currentProgram.getMemory();
            
            // Read DLGTEMPLATE header
            long style = memory.getInt(addr) & 0xFFFFFFFFL;
            long exStyle = memory.getInt(addr.add(4)) & 0xFFFFFFFFL;
            int cdit = memory.getShort(addr.add(8)) & 0xFFFF;
            short x = memory.getShort(addr.add(10));
            short y = memory.getShort(addr.add(12));
            short cx = memory.getShort(addr.add(14));
            short cy = memory.getShort(addr.add(16));
            
            // Create dialog info
            String dialogName = "Dialog_" + addr.toString();
            long dialogId = addr.getOffset() % 0x10000; // Simplified ID
            DialogInfo dialog = new DialogInfo(dialogName, dialogId);
            dialog.x = x;
            dialog.y = y;
            dialog.width = cx;
            dialog.height = cy;
            
            // Skip variable-length fields (menu, class, title)
            Address controlAddr = addr.add(18);
            controlAddr = skipVariableLengthFields(controlAddr);
            
            // Parse controls
            for (int i = 0; i < cdit && i < 100; i++) { // Safety limit
                ControlInfo control = parseDialogControl(controlAddr);
                if (control != null) {
                    control.dialogName = dialogName;
                    dialog.controls.add(control);
                    controlMappings.put(control.controlId, control);
                    
                    // Move to next control (simplified - actual parsing is more complex)
                    controlAddr = controlAddr.add(32); // Approximate control size
                }
            }
            
            dialogLayouts.add(dialog);
            println("Parsed dialog: " + dialogName + " with " + dialog.controls.size() + " controls");
            
        } catch (Exception e) {
            // Error parsing dialog
        }
    }
    
    /**
     * Skip variable-length fields in dialog template
     */
    private Address skipVariableLengthFields(Address addr) {
        // This is a simplified implementation
        // Real implementation would properly parse menu, class, and title fields
        return addr.add(16); // Approximate skip
    }
    
    /**
     * Parse a dialog control
     */
    private ControlInfo parseDialogControl(Address addr) {
        try {
            Memory memory = currentProgram.getMemory();
            
            // Read DLGITEMTEMPLATE (simplified)
            long style = memory.getInt(addr) & 0xFFFFFFFFL;
            long exStyle = memory.getInt(addr.add(4)) & 0xFFFFFFFFL;
            short x = memory.getShort(addr.add(8));
            short y = memory.getShort(addr.add(10));
            short cx = memory.getShort(addr.add(12));
            short cy = memory.getShort(addr.add(14));
            int id = memory.getShort(addr.add(16)) & 0xFFFF;
            
            ControlInfo control = new ControlInfo(id);
            control.x = x;
            control.y = y;
            control.width = cx;
            control.height = cy;
            control.style = style;
            
            // Determine control type from style
            control.controlType = determineControlType(style);
            
            // Try to read control text (simplified)
            control.controlText = readControlText(addr.add(18));
            
            return control;
            
        } catch (Exception e) {
            return null;
        }
    }
    
    /**
     * Determine control type from style bits
     */
    private String determineControlType(long style) {
        // Common control types (simplified)
        if ((style & 0x80) != 0) return "BUTTON";
        if ((style & 0x81) != 0) return "EDIT";
        if ((style & 0x82) != 0) return "STATIC";
        if ((style & 0x83) != 0) return "LISTBOX";
        if ((style & 0x84) != 0) return "SCROLLBAR";
        if ((style & 0x85) != 0) return "COMBOBOX";
        
        return "UNKNOWN";
    }
    
    /**
     * Read control text (simplified)
     */
    private String readControlText(Address addr) {
        try {
            Memory memory = currentProgram.getMemory();
            StringBuilder sb = new StringBuilder();
            
            // Read up to 64 characters
            for (int i = 0; i < 64; i++) {
                char c = (char)(memory.getShort(addr.add(i * 2)) & 0xFFFF);
                if (c == 0) break;
                if (c < 32 || c > 126) break; // Non-printable
                sb.append(c);
            }
            
            return sb.length() > 0 ? sb.toString() : null;
            
        } catch (Exception e) {
            return null;
        }
    }
    
    /**
     * Parse menu resources
     */
    private void parseMenuResources() throws CancelledException {
        if (resourceBlock == null) return;
        
        println("Parsing menu resources...");
        
        try {
            // Look for menu patterns in resource section
            Address addr = resourceBlock.getStart();
            Address endAddr = resourceBlock.getEnd();
            
            while (addr.compareTo(endAddr.subtract(16)) < 0) {
                monitor.checkCanceled();
                
                if (isPotentialMenuTemplate(addr)) {
                    parseMenuTemplate(addr);
                }
                
                addr = addr.add(4);
            }
            
        } catch (Exception e) {
            println("Error parsing menu resources: " + e.getMessage());
        }
    }
    
    /**
     * Check if address points to a potential menu template
     */
    private boolean isPotentialMenuTemplate(Address addr) {
        try {
            Memory memory = currentProgram.getMemory();
            
            // Look for menu header pattern
            int version = memory.getShort(addr) & 0xFFFF;
            int offset = memory.getShort(addr.add(2)) & 0xFFFF;
            
            // Basic validation
            return version == 0 && offset < 1000;
            
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * Parse a menu template
     */
    private void parseMenuTemplate(Address addr) {
        try {
            Memory memory = currentProgram.getMemory();
            Address currentAddr = addr.add(4); // Skip header
            
            // Parse menu items (simplified)
            for (int i = 0; i < 50; i++) { // Safety limit
                int flags = memory.getShort(currentAddr) & 0xFFFF;
                
                if (flags == 0) break; // End of menu
                
                if ((flags & 0x10) == 0) { // Not a popup
                    int menuId = memory.getShort(currentAddr.add(2)) & 0xFFFF;
                    String menuText = readMenuText(currentAddr.add(4));
                    
                    if (menuText != null && menuId > 0) {
                        menuMappings.put((long)menuId, menuText);
                    }
                }
                
                // Move to next item (simplified)
                currentAddr = currentAddr.add(16);
            }
            
        } catch (Exception e) {
            // Error parsing menu
        }
    }
    
    /**
     * Read menu item text
     */
    private String readMenuText(Address addr) {
        try {
            Memory memory = currentProgram.getMemory();
            StringBuilder sb = new StringBuilder();
            
            for (int i = 0; i < 32; i++) {
                char c = (char)(memory.getShort(addr.add(i * 2)) & 0xFFFF);
                if (c == 0) break;
                if (c < 32 || c > 126) break;
                sb.append(c);
            }
            
            return sb.length() > 0 ? sb.toString() : null;
            
        } catch (Exception e) {
            return null;
        }
    }
    
    /**
     * Analyze control ID usage in code
     */
    private void analyzeControlUsage() throws CancelledException {
        println("Analyzing control ID usage in code...");
        
        // Look for control ID constants in the code
        for (Long controlId : controlMappings.keySet()) {
            monitor.checkCanceled();
            findControlIdUsage(controlId);
        }
        
        // Also check menu IDs
        for (Long menuId : menuMappings.keySet()) {
            monitor.checkCanceled();
            findControlIdUsage(menuId);
        }
    }
    
    /**
     * Find usage of a specific control ID in the code
     */
    private void findControlIdUsage(Long controlId) {
        try {
            Memory memory = currentProgram.getMemory();
            AddressSetView searchSet = currentProgram.getMemory().getExecuteSet();
            
            // Search for the control ID as immediate values
            byte[] searchBytes = new byte[4];
            long id = controlId;
            searchBytes[0] = (byte)(id & 0xFF);
            searchBytes[1] = (byte)((id >> 8) & 0xFF);
            searchBytes[2] = (byte)((id >> 16) & 0xFF);
            searchBytes[3] = (byte)((id >> 24) & 0xFF);
            
            Address found = memory.findBytes(searchSet.getMinAddress(), searchBytes, null, true, monitor);
            int foundCount = 0;
            
            while (found != null && foundCount < 10 && !monitor.isCancelled()) {
                // Add comment at the usage location
                addControlIdComment(found, controlId);
                
                foundCount++;
                found = memory.findBytes(found.add(1), searchBytes, null, true, monitor);
            }
            
        } catch (Exception e) {
            // Error searching for control ID
        }
    }
    
    /**
     * Add comment for control ID usage
     */
    private void addControlIdComment(Address addr, Long controlId) {
        try {
            CodeUnit codeUnit = currentProgram.getListing().getCodeUnitAt(addr);
            if (codeUnit != null) {
                ControlInfo control = controlMappings.get(controlId);
                String menuText = menuMappings.get(controlId);
                
                String comment = "Control ID " + controlId;
                
                if (control != null) {
                    comment += ": " + control.toString();
                } else if (menuText != null) {
                    comment += ": Menu \"" + menuText + "\"";
                }
                
                String existingComment = codeUnit.getComment(CodeUnit.EOL_COMMENT);
                if (existingComment != null && !existingComment.isEmpty()) {
                    comment = existingComment + "; " + comment;
                }
                
                codeUnit.setComment(CodeUnit.EOL_COMMENT, comment);
            }
            
        } catch (Exception e) {
            // Error adding comment
        }
    }
    
    /**
     * Create symbols for control IDs
     */
    private void createControlSymbols() throws Exception {
        SymbolTable symbolTable = currentProgram.getSymbolTable();
        
        // Create symbols for control IDs
        for (Map.Entry<Long, ControlInfo> entry : controlMappings.entrySet()) {
            Long controlId = entry.getKey();
            ControlInfo control = entry.getValue();
            
            try {
                String symbolName = "IDC_" + control.controlType + "_" + controlId;
                if (control.controlText != null && !control.controlText.isEmpty()) {
                    // Create a clean symbol name from control text
                    String cleanText = control.controlText.replaceAll("[^a-zA-Z0-9_]", "_");
                    symbolName = "IDC_" + cleanText;
                }
                
                // Create equate for the control ID value
                currentProgram.getEquateTable().createEquate(symbolName, controlId);
                
            } catch (Exception e) {
                // Symbol might already exist
            }
        }
        
        // Create symbols for menu IDs
        for (Map.Entry<Long, String> entry : menuMappings.entrySet()) {
            Long menuId = entry.getKey();
            String menuText = entry.getValue();
            
            try {
                String cleanText = menuText.replaceAll("[^a-zA-Z0-9_]", "_");
                String symbolName = "IDM_" + cleanText;
                
                currentProgram.getEquateTable().createEquate(symbolName, menuId);
                
            } catch (Exception e) {
                // Symbol might already exist
            }
        }
        
        println("Created symbols for " + controlMappings.size() + " controls and " + 
                menuMappings.size() + " menu items");
    }
    
    /**
     * Generate control mapping report
     */
    private void generateControlReport() {
        println("\\n=== MFC Control ID Resolution Report ===");
        
        // Dialog report
        if (!dialogLayouts.isEmpty()) {
            println("\\nDialogs (" + dialogLayouts.size() + "):");
            println("----------------------------------------");
            
            for (DialogInfo dialog : dialogLayouts) {
                println("Dialog: " + dialog.dialogName + " (ID: " + dialog.dialogId + ")");
                println("  Size: " + dialog.width + "x" + dialog.height + 
                       " at (" + dialog.x + "," + dialog.y + ")");
                println("  Controls: " + dialog.controls.size());
                
                for (ControlInfo control : dialog.controls) {
                    println("    " + control.toString());
                }
                println();
            }
        }
        
        // Menu report
        if (!menuMappings.isEmpty()) {
            println("\\nMenu Items (" + menuMappings.size() + "):");
            println("----------------------------------------");
            
            for (Map.Entry<Long, String> entry : menuMappings.entrySet()) {
                println("  ID " + entry.getKey() + ": \"" + entry.getValue() + "\"");
            }
        }
        
        // String table report
        if (!stringMappings.isEmpty()) {
            println("\\nString Table (" + stringMappings.size() + " entries):");
            println("----------------------------------------");
            
            for (Map.Entry<Long, String> entry : stringMappings.entrySet()) {
                println("  ID " + entry.getKey() + ": \"" + entry.getValue() + "\"");
            }
        }
        
        // Summary
        println("\\n=== Summary ===");
        println("Total controls resolved: " + controlMappings.size());
        println("Menu items found: " + menuMappings.size());
        println("String table entries: " + stringMappings.size());
        println("Dialogs parsed: " + dialogLayouts.size());
        
        if (resourceBlock == null) {
            println("\\nNote: No resource section found. Resolution was limited to code analysis.");
        }
    }
}

