//MFC Structure Definitions for Ghidra Analysis
//Defines core MFC data structures for reverse engineering MFC applications
//@author MFC Analysis Scripts
//@category MFC
//@keybinding 
//@menupath Tools.MFC.Define MFC Structures
//@toolbar 

import ghidra.app.script.GhidraScript;
import ghidra.program.model.data.*;
import ghidra.program.model.listing.Program;
import ghidra.util.exception.DuplicateNameException;
import ghidra.util.exception.InvalidInputException;

public class MFCStructures extends GhidraScript {
    
    private DataTypeManager dtm;
    private CategoryPath mfcCategory;
    
    @Override
    public void run() throws Exception {
        dtm = currentProgram.getDataTypeManager();
        mfcCategory = new CategoryPath("/MFC");
        
        println("Creating MFC structure definitions...");
        
        // Create core MFC structures
        createAFXMsgMapEntry();
        createAFXMsgMap();
        createCRuntimeClass();
        createMFCConstants();
        
        println("MFC structures created successfully!");
        println("Structures are available in the Data Type Manager under /MFC category");
    }
    
    /**
     * Creates the AFX_MSGMAP_ENTRY structure
     */
    private void createAFXMsgMapEntry() throws Exception {
        StructureDataType msgMapEntry = new StructureDataType(mfcCategory, "AFX_MSGMAP_ENTRY", 0);
        
        // Add structure members
        msgMapEntry.add(new DWordDataType(), "nMessage", "Windows message ID (WM_COMMAND, WM_NOTIFY, etc.)");
        msgMapEntry.add(new DWordDataType(), "nCode", "Control notification code");
        msgMapEntry.add(new DWordDataType(), "nID", "Control ID or command ID");
        msgMapEntry.add(new DWordDataType(), "nLastID", "Last ID in range (for ID ranges)");
        
        // nSig field - signature type (pointer sized)
        if (currentProgram.getDefaultPointerSize() == 8) {
            msgMapEntry.add(new QWordDataType(), "nSig", "Signature type or special value");
        } else {
            msgMapEntry.add(new DWordDataType(), "nSig", "Signature type or special value");
        }
        
        // pfn field - function pointer
        msgMapEntry.add(new PointerDataType(), "pfn", "Message handler function pointer");
        
        // Add to data type manager
        dtm.addDataType(msgMapEntry, DataTypeConflictHandler.REPLACE_HANDLER);
        println("Created AFX_MSGMAP_ENTRY structure (" + msgMapEntry.getLength() + " bytes)");
    }
    
    /**
     * Creates the AFX_MSGMAP structure
     */
    private void createAFXMsgMap() throws Exception {
        StructureDataType msgMap = new StructureDataType(mfcCategory, "AFX_MSGMAP", 0);
        
        // Add structure members
        msgMap.add(new PointerDataType(), "pBaseMap", "Pointer to base class message map");
        msgMap.add(new PointerDataType(), "lpEntries", "Pointer to message map entries array");
        
        // Add to data type manager
        dtm.addDataType(msgMap, DataTypeConflictHandler.REPLACE_HANDLER);
        println("Created AFX_MSGMAP structure (" + msgMap.getLength() + " bytes)");
    }
    
    /**
     * Creates the CRuntimeClass structure
     */
    private void createCRuntimeClass() throws Exception {
        StructureDataType runtimeClass = new StructureDataType(mfcCategory, "CRuntimeClass", 0);
        
        // Add structure members
        runtimeClass.add(new PointerDataType(new CharDataType()), "m_lpszClassName", "Class name string");
        runtimeClass.add(new DWordDataType(), "m_nObjectSize", "Size of object instance");
        runtimeClass.add(new WordDataType(), "m_wSchema", "Schema version");
        runtimeClass.add(new PointerDataType(), "m_pfnCreateObject", "Object creation function");
        runtimeClass.add(new PointerDataType(), "m_pBaseClass", "Base class runtime info");
        runtimeClass.add(new PointerDataType(), "m_pNextClass", "Next class in chain");
        runtimeClass.add(new PointerDataType(), "m_pClassInit", "Class initialization data");
        
        // Add to data type manager
        dtm.addDataType(runtimeClass, DataTypeConflictHandler.REPLACE_HANDLER);
        println("Created CRuntimeClass structure (" + runtimeClass.getLength() + " bytes)");
    }
    
    /**
     * Creates MFC constants and enums
     */
    private void createMFCConstants() throws Exception {
        // Create MFC signature enum
        EnumDataType sigEnum = new EnumDataType(mfcCategory, "AFX_SIG", 1);
        
        // Add signature constants
        sigEnum.add("AfxSig_end", 0);      // End of message map
        sigEnum.add("AfxSig_bD", 1);       // BOOL (CDC*)
        sigEnum.add("AfxSig_bb", 2);       // BOOL (BOOL)
        sigEnum.add("AfxSig_bWww", 3);     // BOOL (CWnd*, WORD, WORD)
        sigEnum.add("AfxSig_hv", 4);       // HBRUSH ()
        sigEnum.add("AfxSig_vv", 5);       // void ()
        sigEnum.add("AfxSig_vw", 6);       // void (WORD)
        sigEnum.add("AfxSig_vww", 7);      // void (WORD, WORD)
        sigEnum.add("AfxSig_vvii", 8);     // void (int, int)
        sigEnum.add("AfxSig_vwl", 9);      // void (WORD, LONG)
        sigEnum.add("AfxSig_lwl", 10);     // LONG (WORD, LONG)
        sigEnum.add("AfxSig_vwwM", 11);    // void (WORD, WORD, CMenu*)
        sigEnum.add("AfxSig_vD", 12);      // void (CDC*)
        
        dtm.addDataType(sigEnum, DataTypeConflictHandler.REPLACE_HANDLER);
        
        // Create Windows message constants enum
        EnumDataType wmEnum = new EnumDataType(mfcCategory, "WINDOWS_MESSAGES", 4);
        
        // Add common Windows messages
        wmEnum.add("WM_NULL", 0x0000);
        wmEnum.add("WM_CREATE", 0x0001);
        wmEnum.add("WM_DESTROY", 0x0002);
        wmEnum.add("WM_MOVE", 0x0003);
        wmEnum.add("WM_SIZE", 0x0005);
        wmEnum.add("WM_ACTIVATE", 0x0006);
        wmEnum.add("WM_SETFOCUS", 0x0007);
        wmEnum.add("WM_KILLFOCUS", 0x0008);
        wmEnum.add("WM_PAINT", 0x000F);
        wmEnum.add("WM_CLOSE", 0x0010);
        wmEnum.add("WM_QUIT", 0x0012);
        wmEnum.add("WM_COMMAND", 0x0111);
        wmEnum.add("WM_SYSCOMMAND", 0x0112);
        wmEnum.add("WM_TIMER", 0x0113);
        wmEnum.add("WM_HSCROLL", 0x0114);
        wmEnum.add("WM_VSCROLL", 0x0115);
        wmEnum.add("WM_INITMENU", 0x0116);
        wmEnum.add("WM_INITMENUPOPUP", 0x0117);
        wmEnum.add("WM_NOTIFY", 0x004E);
        wmEnum.add("WM_USER", 0x0400);
        
        dtm.addDataType(wmEnum, DataTypeConflictHandler.REPLACE_HANDLER);
        
        // Create control notification constants
        EnumDataType cnEnum = new EnumDataType(mfcCategory, "CONTROL_NOTIFICATIONS", 4);
        
        // Button notifications
        cnEnum.add("BN_CLICKED", 0);
        cnEnum.add("BN_PAINT", 1);
        cnEnum.add("BN_HILITE", 2);
        cnEnum.add("BN_UNHILITE", 3);
        cnEnum.add("BN_DISABLE", 4);
        cnEnum.add("BN_DOUBLECLICKED", 5);
        cnEnum.add("BN_SETFOCUS", 6);
        cnEnum.add("BN_KILLFOCUS", 7);
        
        // Edit control notifications
        cnEnum.add("EN_SETFOCUS", 0x0100);
        cnEnum.add("EN_KILLFOCUS", 0x0200);
        cnEnum.add("EN_CHANGE", 0x0300);
        cnEnum.add("EN_UPDATE", 0x0400);
        cnEnum.add("EN_ERRSPACE", 0x0500);
        cnEnum.add("EN_MAXTEXT", 0x0501);
        cnEnum.add("EN_HSCROLL", 0x0601);
        cnEnum.add("EN_VSCROLL", 0x0602);
        
        // Listbox notifications
        cnEnum.add("LBN_ERRSPACE", -2);
        cnEnum.add("LBN_SELCHANGE", 1);
        cnEnum.add("LBN_DBLCLK", 2);
        cnEnum.add("LBN_SELCANCEL", 3);
        cnEnum.add("LBN_SETFOCUS", 4);
        cnEnum.add("LBN_KILLFOCUS", 5);
        
        dtm.addDataType(cnEnum, DataTypeConflictHandler.REPLACE_HANDLER);
        
        println("Created MFC constants and enums");
    }
}

