//MFC Message Handler Mapper
//Maps message IDs to handler functions and creates cross-references
//@author MFC Analysis Scripts
//@category MFC
//@keybinding 
//@menupath Tools.MFC.Map Message Handlers
//@toolbar 

import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.*;
import ghidra.program.model.data.*;
import ghidra.program.model.listing.*;
import ghidra.program.model.mem.*;
import ghidra.program.model.symbol.*;
import ghidra.util.exception.CancelledException;
import java.util.*;

public class MFCMessageMapper extends GhidraScript {
    
    private Map<String, MessageMapping> messageMappings;
    private Map<Long, String> messageIdToName;
    private Map<Long, String> controlIdToName;
    private List<CrossReferenceInfo> crossReferences;
    
    // Message mapping information
    private static class MessageMapping {
        String className;
        long messageId;
        long notificationCode;
        long controlId;
        Address handlerFunction;
        String messageType;
        String description;
        
        MessageMapping(String cls, long msg, long code, long ctrl, Address handler) {
            this.className = cls;
            this.messageId = msg;
            this.notificationCode = code;
            this.controlId = ctrl;
            this.handlerFunction = handler;
            this.messageType = determineMessageType(msg, code);
            this.description = buildDescription();
        }
        
        private String determineMessageType(long msg, long code) {
            if (msg == 0x0111) { // WM_COMMAND
                if (code == 0) return "COMMAND";
                else return "CONTROL_NOTIFICATION";
            } else if (msg == 0xFFFFFFFF) {
                return "UPDATE_UI";
            } else if (msg >= 0x0001 && msg <= 0x03FF) {
                return "SYSTEM_MESSAGE";
            } else if (msg >= 0x0400) {
                return "USER_MESSAGE";
            }
            return "UNKNOWN";
        }
        
        private String buildDescription() {
            StringBuilder desc = new StringBuilder();
            desc.append(messageType).append(": ");
            
            switch (messageType) {
                case "COMMAND":
                    desc.append("Command ID ").append(controlId);
                    break;
                case "CONTROL_NOTIFICATION":
                    desc.append("Control ").append(controlId).append(" notification ").append(notificationCode);
                    break;
                case "UPDATE_UI":
                    desc.append("Update UI for command ").append(controlId);
                    break;
                case "SYSTEM_MESSAGE":
                    desc.append("Windows message 0x").append(Long.toHexString(messageId));
                    break;
                default:
                    desc.append("Message 0x").append(Long.toHexString(messageId));
            }
            
            return desc.toString();
        }
    }
    
    // Cross-reference information
    private static class CrossReferenceInfo {
        Address fromAddress;
        Address toAddress;
        String referenceType;
        String description;
        
        CrossReferenceInfo(Address from, Address to, String type, String desc) {
            this.fromAddress = from;
            this.toAddress = to;
            this.referenceType = type;
            this.description = desc;
        }
    }
    
    @Override
    public void run() throws Exception {
        messageMappings = new HashMap<>();
        messageIdToName = new HashMap<>();
        controlIdToName = new HashMap<>();
        crossReferences = new ArrayList<>();
        
        println("Starting MFC message mapping analysis...");
        
        // Step 1: Initialize message and control ID mappings
        initializeMessageMappings();
        
        // Step 2: Scan for message maps and extract mappings
        scanMessageMaps();
        
        // Step 3: Analyze message flow and create cross-references
        analyzeMessageFlow();
        
        // Step 4: Create enhanced function comments
        enhanceFunctionComments();
        
        // Step 5: Generate message mapping report
        generateMappingReport();
        
        println("Message mapping analysis completed!");
        println("Found " + messageMappings.size() + " message mappings");
    }
    
    /**
     * Initialize standard Windows message and control notification mappings
     */
    private void initializeMessageMappings() {
        // Standard Windows messages
        messageIdToName.put(0x0000L, "WM_NULL");
        messageIdToName.put(0x0001L, "WM_CREATE");
        messageIdToName.put(0x0002L, "WM_DESTROY");
        messageIdToName.put(0x0003L, "WM_MOVE");
        messageIdToName.put(0x0005L, "WM_SIZE");
        messageIdToName.put(0x0006L, "WM_ACTIVATE");
        messageIdToName.put(0x0007L, "WM_SETFOCUS");
        messageIdToName.put(0x0008L, "WM_KILLFOCUS");
        messageIdToName.put(0x000FL, "WM_PAINT");
        messageIdToName.put(0x0010L, "WM_CLOSE");
        messageIdToName.put(0x0012L, "WM_QUIT");
        messageIdToName.put(0x0111L, "WM_COMMAND");
        messageIdToName.put(0x0112L, "WM_SYSCOMMAND");
        messageIdToName.put(0x0113L, "WM_TIMER");
        messageIdToName.put(0x0114L, "WM_HSCROLL");
        messageIdToName.put(0x0115L, "WM_VSCROLL");
        messageIdToName.put(0x0116L, "WM_INITMENU");
        messageIdToName.put(0x0117L, "WM_INITMENUPOPUP");
        messageIdToName.put(0x004EL, "WM_NOTIFY");
        messageIdToName.put(0xFFFFFFFFL, "UPDATE_COMMAND_UI");
        
        // Control notification codes
        controlIdToName.put(0L, "BN_CLICKED");
        controlIdToName.put(1L, "BN_PAINT");
        controlIdToName.put(2L, "BN_HILITE");
        controlIdToName.put(3L, "BN_UNHILITE");
        controlIdToName.put(4L, "BN_DISABLE");
        controlIdToName.put(5L, "BN_DOUBLECLICKED");
        controlIdToName.put(6L, "BN_SETFOCUS");
        controlIdToName.put(7L, "BN_KILLFOCUS");
        
        controlIdToName.put(0x0100L, "EN_SETFOCUS");
        controlIdToName.put(0x0200L, "EN_KILLFOCUS");
        controlIdToName.put(0x0300L, "EN_CHANGE");
        controlIdToName.put(0x0400L, "EN_UPDATE");
        controlIdToName.put(0x0500L, "EN_ERRSPACE");
        controlIdToName.put(0x0501L, "EN_MAXTEXT");
        
        controlIdToName.put(1L, "LBN_SELCHANGE");
        controlIdToName.put(2L, "LBN_DBLCLK");
        controlIdToName.put(3L, "LBN_SELCANCEL");
        controlIdToName.put(4L, "LBN_SETFOCUS");
        controlIdToName.put(5L, "LBN_KILLFOCUS");
    }
    
    /**
     * Scan for message maps and extract message mappings
     */
    private void scanMessageMaps() throws CancelledException {
        SymbolTable symbolTable = currentProgram.getSymbolTable();
        
        // Find message map symbols
        SymbolIterator symbols = symbolTable.getAllSymbols(true);
        while (symbols.hasNext()) {
            monitor.checkCanceled();
            Symbol symbol = symbols.next();
            String name = symbol.getName();
            
            if (name.contains("messageMap") || name.contains("MessageMap")) {
                analyzeMessageMapAtAddress(symbol.getAddress(), extractClassNameFromSymbol(name));
            }
        }
        
        // Also scan for AFX_MSGMAP structures
        scanForMsgMapStructures();
    }
    
    /**
     * Scan for AFX_MSGMAP structures
     */
    private void scanForMsgMapStructures() throws CancelledException {
        DataTypeManager dtm = currentProgram.getDataTypeManager();
        DataType msgMapType = dtm.getDataType(new CategoryPath("/MFC"), "AFX_MSGMAP");
        
        if (msgMapType == null) return;
        
        // Find all instances of AFX_MSGMAP
        AddressSetView dataAddresses = currentProgram.getMemory().getLoadedAndInitializedAddressSet();
        AddressIterator addresses = dataAddresses.getAddresses(true);
        
        while (addresses.hasNext()) {
            monitor.checkCanceled();
            Address addr = addresses.next();
            Data data = currentProgram.getListing().getDataAt(addr);
            
            if (data != null && data.getDataType().equals(msgMapType)) {
                String className = findClassNameForMessageMap(addr);
                analyzeMessageMapAtAddress(addr, className);
            }
        }
    }
    
    /**
     * Analyze message map at specific address
     */
    private void analyzeMessageMapAtAddress(Address mapAddr, String className) {
        try {
            Memory memory = currentProgram.getMemory();
            int ptrSize = currentProgram.getDefaultPointerSize();
            
            // Read AFX_MSGMAP structure
            long entriesPtr = ptrSize == 8 ? memory.getLong(mapAddr.add(ptrSize)) : memory.getInt(mapAddr.add(ptrSize)) & 0xFFFFFFFFL;
            
            if (entriesPtr != 0) {
                Address entriesAddr = currentProgram.getAddressFactory().getDefaultAddressSpace().getAddress(entriesPtr);
                extractMessageMappings(entriesAddr, className);
            }
            
        } catch (Exception e) {
            println("Error analyzing message map at " + mapAddr + ": " + e.getMessage());
        }
    }
    
    /**
     * Extract message mappings from message map entries
     */
    private void extractMessageMappings(Address entriesAddr, String className) {
        try {
            Memory memory = currentProgram.getMemory();
            DataTypeManager dtm = currentProgram.getDataTypeManager();
            DataType entryType = dtm.getDataType(new CategoryPath("/MFC"), "AFX_MSGMAP_ENTRY");
            
            if (entryType == null) return;
            
            int entrySize = entryType.getLength();
            Address currentAddr = entriesAddr;
            int entryIndex = 0;
            
            while (entryIndex < 100) { // Safety limit
                // Read message map entry
                long nMessage = memory.getInt(currentAddr) & 0xFFFFFFFFL;
                long nCode = memory.getInt(currentAddr.add(4)) & 0xFFFFFFFFL;
                long nID = memory.getInt(currentAddr.add(8)) & 0xFFFFFFFFL;
                long nLastID = memory.getInt(currentAddr.add(12)) & 0xFFFFFFFFL;
                
                // Check for terminator
                if (nMessage == 0 && nCode == 0 && nID == 0) {
                    break;
                }
                
                // Get function pointer
                Address pfnAddr;
                if (currentProgram.getDefaultPointerSize() == 8) {
                    long pfnValue = memory.getLong(currentAddr.add(24));
                    pfnAddr = pfnValue != 0 ? currentProgram.getAddressFactory().getDefaultAddressSpace().getAddress(pfnValue) : null;
                } else {
                    long pfnValue = memory.getInt(currentAddr.add(20)) & 0xFFFFFFFFL;
                    pfnAddr = pfnValue != 0 ? currentProgram.getAddressFactory().getDefaultAddressSpace().getAddress(pfnValue) : null;
                }
                
                if (pfnAddr != null) {
                    String mappingKey = className + "_" + nMessage + "_" + nCode + "_" + nID;
                    MessageMapping mapping = new MessageMapping(className, nMessage, nCode, nID, pfnAddr);
                    messageMappings.put(mappingKey, mapping);
                    
                    println("Mapped " + mapping.description + " -> " + pfnAddr + " in " + className);
                }
                
                currentAddr = currentAddr.add(entrySize);
                entryIndex++;
            }
            
        } catch (Exception e) {
            println("Error extracting message mappings: " + e.getMessage());
        }
    }
    
    /**
     * Find class name for message map
     */
    private String findClassNameForMessageMap(Address mapAddr) {
        SymbolTable symbolTable = currentProgram.getSymbolTable();
        
        // Check direct symbols
        Symbol[] symbols = symbolTable.getSymbols(mapAddr);
        for (Symbol symbol : symbols) {
            String name = symbol.getName();
            if (name.contains("messageMap")) {
                return extractClassNameFromSymbol(name);
            }
        }
        
        // Look for references
        ReferenceManager refMgr = currentProgram.getReferenceManager();
        ReferenceIterator refs = refMgr.getReferencesTo(mapAddr);
        
        while (refs.hasNext()) {
            Reference ref = refs.next();
            Address fromAddr = ref.getFromAddress();
            
            Function func = currentProgram.getFunctionManager().getFunctionContaining(fromAddr);
            if (func != null) {
                String funcName = func.getName();
                if (funcName.contains("GetMessageMap")) {
                    return extractClassNameFromSymbol(funcName);
                }
            }
        }
        
        return "UnknownClass_" + mapAddr.toString();
    }
    
    /**
     * Extract class name from symbol
     */
    private String extractClassNameFromSymbol(String symbolName) {
        if (symbolName.contains("::")) {
            return symbolName.substring(0, symbolName.indexOf("::"));
        }
        
        if (symbolName.contains("GetMessageMap")) {
            int end = symbolName.indexOf("GetMessageMap");
            if (end > 0) {
                return symbolName.substring(0, end).replaceAll("_+$", "");
            }
        }
        
        if (symbolName.contains("messageMap")) {
            int end = symbolName.indexOf("messageMap");
            if (end > 0) {
                return symbolName.substring(0, end).replaceAll("_+$", "");
            }
        }
        
        return symbolName;
    }
    
    /**
     * Analyze message flow and create cross-references
     */
    private void analyzeMessageFlow() throws CancelledException {
        println("Analyzing message flow...");
        
        for (MessageMapping mapping : messageMappings.values()) {
            monitor.checkCanceled();
            analyzeMessageFlowForMapping(mapping);
        }
        
        // Apply cross-references
        applyCrossReferences();
    }
    
    /**
     * Analyze message flow for a specific mapping
     */
    private void analyzeMessageFlowForMapping(MessageMapping mapping) {
        // Create cross-reference from message map entry to handler function
        Address entryAddr = findMessageMapEntryAddress(mapping);
        if (entryAddr != null) {
            CrossReferenceInfo xref = new CrossReferenceInfo(
                entryAddr, mapping.handlerFunction, "MESSAGE_HANDLER", 
                "Handles " + mapping.description
            );
            crossReferences.add(xref);
        }
        
        // Look for calls to this handler function
        analyzeHandlerCalls(mapping);
        
        // Look for UI element references
        analyzeUIReferences(mapping);
    }
    
    /**
     * Find the address of a message map entry
     */
    private Address findMessageMapEntryAddress(MessageMapping mapping) {
        // This would require scanning message map entries to find the specific one
        // For now, return null - in a full implementation, we'd track entry addresses
        return null;
    }
    
    /**
     * Analyze calls to handler function
     */
    private void analyzeHandlerCalls(MessageMapping mapping) {
        ReferenceManager refMgr = currentProgram.getReferenceManager();
        ReferenceIterator refs = refMgr.getReferencesTo(mapping.handlerFunction);
        
        while (refs.hasNext()) {
            Reference ref = refs.next();
            Address fromAddr = ref.getFromAddress();
            
            // Check if this is a call from the message dispatching code
            Function callingFunc = currentProgram.getFunctionManager().getFunctionContaining(fromAddr);
            if (callingFunc != null) {
                String funcName = callingFunc.getName();
                if (funcName.contains("WindowProc") || funcName.contains("OnCmdMsg") || funcName.contains("DispatchMessage")) {
                    CrossReferenceInfo xref = new CrossReferenceInfo(
                        fromAddr, mapping.handlerFunction, "MESSAGE_DISPATCH",
                        "Dispatches " + mapping.description
                    );
                    crossReferences.add(xref);
                }
            }
        }
    }
    
    /**
     * Analyze UI element references
     */
    private void analyzeUIReferences(MessageMapping mapping) {
        if (mapping.controlId > 0 && mapping.controlId < 0x10000) {
            // Look for references to this control ID in the code
            findControlIdReferences(mapping.controlId, mapping.handlerFunction);
        }
    }
    
    /**
     * Find references to a control ID
     */
    private void findControlIdReferences(long controlId, Address handlerAddr) {
        // Search for the control ID value in the code
        Memory memory = currentProgram.getMemory();
        AddressSetView searchSet = currentProgram.getMemory().getExecuteSet();
        
        try {
            // Search for the control ID as a 32-bit value
            byte[] searchBytes = new byte[4];
            searchBytes[0] = (byte)(controlId & 0xFF);
            searchBytes[1] = (byte)((controlId >> 8) & 0xFF);
            searchBytes[2] = (byte)((controlId >> 16) & 0xFF);
            searchBytes[3] = (byte)((controlId >> 24) & 0xFF);
            
            Address found = memory.findBytes(searchSet.getMinAddress(), searchBytes, null, true, monitor);
            while (found != null && !monitor.isCancelled()) {
                // Check if this is in a function that might be related
                Function func = currentProgram.getFunctionManager().getFunctionContaining(found);
                if (func != null) {
                    CrossReferenceInfo xref = new CrossReferenceInfo(
                        found, handlerAddr, "CONTROL_REFERENCE",
                        "References control ID " + controlId
                    );
                    crossReferences.add(xref);
                }
                
                // Find next occurrence
                found = memory.findBytes(found.add(1), searchBytes, null, true, monitor);
            }
            
        } catch (Exception e) {
            // Error searching for control ID
        }
    }
    
    /**
     * Apply cross-references to Ghidra
     */
    private void applyCrossReferences() throws Exception {
        ReferenceManager refMgr = currentProgram.getReferenceManager();
        
        for (CrossReferenceInfo xref : crossReferences) {
            try {
                // Create the cross-reference
                refMgr.addMemoryReference(xref.fromAddress, xref.toAddress, 
                                        RefType.DATA, SourceType.ANALYSIS, 0);
                
                // Add comment at the reference location
                CodeUnit codeUnit = currentProgram.getListing().getCodeUnitAt(xref.fromAddress);
                if (codeUnit != null) {
                    String existingComment = codeUnit.getComment(CodeUnit.EOL_COMMENT);
                    String newComment = xref.description;
                    
                    if (existingComment != null && !existingComment.isEmpty()) {
                        newComment = existingComment + "; " + newComment;
                    }
                    
                    codeUnit.setComment(CodeUnit.EOL_COMMENT, newComment);
                }
                
            } catch (Exception e) {
                // Reference might already exist
            }
        }
        
        println("Applied " + crossReferences.size() + " cross-references");
    }
    
    /**
     * Enhance function comments with message mapping information
     */
    private void enhanceFunctionComments() {
        for (MessageMapping mapping : messageMappings.values()) {
            Function func = currentProgram.getFunctionManager().getFunctionAt(mapping.handlerFunction);
            if (func != null) {
                enhanceFunctionComment(func, mapping);
            }
        }
    }
    
    /**
     * Enhance a single function's comment
     */
    private void enhanceFunctionComment(Function func, MessageMapping mapping) {
        StringBuilder comment = new StringBuilder();
        
        // Add existing comment if any
        String existingComment = func.getComment();
        if (existingComment != null && !existingComment.isEmpty()) {
            comment.append(existingComment).append("\\n\\n");
        }
        
        // Add MFC message handler information
        comment.append("=== MFC Message Handler ===\\n");
        comment.append("Class: ").append(mapping.className).append("\\n");
        comment.append("Message: ").append(getMessageName(mapping.messageId)).append("\\n");
        
        if (mapping.messageType.equals("CONTROL_NOTIFICATION")) {
            comment.append("Notification: ").append(getNotificationName(mapping.notificationCode)).append("\\n");
            comment.append("Control ID: ").append(mapping.controlId).append("\\n");
        } else if (mapping.messageType.equals("COMMAND")) {
            comment.append("Command ID: ").append(mapping.controlId).append("\\n");
        } else if (mapping.messageType.equals("UPDATE_UI")) {
            comment.append("Update UI for Command ID: ").append(mapping.controlId).append("\\n");
        }
        
        comment.append("Type: ").append(mapping.messageType).append("\\n");
        comment.append("Description: ").append(mapping.description);
        
        func.setComment(comment.toString());
    }
    
    /**
     * Get message name from ID
     */
    private String getMessageName(long messageId) {
        String name = messageIdToName.get(messageId);
        if (name != null) {
            return name + " (0x" + Long.toHexString(messageId) + ")";
        }
        return "0x" + Long.toHexString(messageId);
    }
    
    /**
     * Get notification name from code
     */
    private String getNotificationName(long notificationCode) {
        String name = controlIdToName.get(notificationCode);
        if (name != null) {
            return name + " (" + notificationCode + ")";
        }
        return String.valueOf(notificationCode);
    }
    
    /**
     * Generate message mapping report
     */
    private void generateMappingReport() {
        println("\\n=== MFC Message Mapping Report ===");
        
        // Group mappings by class
        Map<String, List<MessageMapping>> classMappings = new HashMap<>();
        for (MessageMapping mapping : messageMappings.values()) {
            classMappings.computeIfAbsent(mapping.className, k -> new ArrayList<>()).add(mapping);
        }
        
        // Print report for each class
        for (Map.Entry<String, List<MessageMapping>> entry : classMappings.entrySet()) {
            String className = entry.getKey();
            List<MessageMapping> mappings = entry.getValue();
            
            println("\\nClass: " + className + " (" + mappings.size() + " handlers)");
            println("----------------------------------------");
            
            // Sort mappings by message type
            mappings.sort((a, b) -> {
                int typeCompare = a.messageType.compareTo(b.messageType);
                if (typeCompare != 0) return typeCompare;
                return Long.compare(a.messageId, b.messageId);
            });
            
            for (MessageMapping mapping : mappings) {
                println("  " + mapping.description + " -> " + mapping.handlerFunction);
            }
        }
        
        // Summary statistics
        println("\\n=== Summary ===");
        println("Total message mappings: " + messageMappings.size());
        println("Classes with handlers: " + classMappings.size());
        println("Cross-references created: " + crossReferences.size());
        
        // Count by message type
        Map<String, Integer> typeCounts = new HashMap<>();
        for (MessageMapping mapping : messageMappings.values()) {
            typeCounts.merge(mapping.messageType, 1, Integer::sum);
        }
        
        println("\\nMessage types:");
        for (Map.Entry<String, Integer> entry : typeCounts.entrySet()) {
            println("  " + entry.getKey() + ": " + entry.getValue());
        }
    }
}

