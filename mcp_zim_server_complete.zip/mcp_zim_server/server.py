"""
MCP ZIM Server - Main server implementation

Author: mobilemutex
"""

import asyncio
import logging
from typing import Any, Dict, List, Optional
from mcp.server.fastmcp import FastMCP, Context
from mcp.server.session import ServerSession
from .config import load_config
from .zim_manager import ZimManager
from .search_engine import SearchEngine
from .content_extractor import ContentExtractor
from .file_discovery import FileDiscovery
from .utils import setup_logging


# Load configuration
config = load_config()

# Set up logging
logger = setup_logging(config.log_level)

# Initialize ZIM manager
zim_manager = ZimManager(config)

# Initialize search engine
search_engine = SearchEngine(config, zim_manager)

# Initialize content extractor
content_extractor = ContentExtractor(config, zim_manager)

# Initialize file discovery
file_discovery = FileDiscovery(config)

# Create MCP server
mcp = FastMCP("ZIM Server")


@mcp.tool()
def list_zim_files(directory: Optional[str] = None) -> Dict[str, Any]:
    """
    List all available ZIM files in the configured directory.
    
    Args:
        directory: Optional specific directory to scan (not implemented yet for security)
    
    Returns:
        Dictionary containing list of ZIM files with metadata
    """
    try:
        logger.info("Listing ZIM files")
        
        # Discover ZIM files
        zim_files = zim_manager.discover_zim_files()
        
        # Format response
        files_data = []
        for file_info in zim_files:
            files_data.append({
                "filename": file_info.filename,
                "title": file_info.title,
                "description": file_info.description,
                "size": file_info.size_formatted,
                "article_count": file_info.article_count,
                "media_count": file_info.media_count,
                "language": file_info.language,
                "creator": file_info.creator,
                "date": file_info.date,
                "has_fulltext_index": file_info.has_fulltext_index,
                "has_title_index": file_info.has_title_index
            })
        
        return {
            "status": "success",
            "count": len(files_data),
            "files": files_data
        }
        
    except Exception as e:
        logger.error(f"Error listing ZIM files: {e}")
        return {
            "status": "error",
            "error": "ZimFileError",
            "message": f"Failed to list ZIM files: {str(e)}"
        }


@mcp.tool()
def get_zim_metadata(zim_file: str) -> Dict[str, Any]:
    """
    Get detailed metadata about a specific ZIM file.
    
    Args:
        zim_file: Name or path of the ZIM file
    
    Returns:
        Dictionary containing detailed ZIM file metadata
    """
    try:
        logger.info(f"Getting metadata for ZIM file: {zim_file}")
        
        # Get file info
        file_info = zim_manager.get_zim_file_info(zim_file)
        
        if file_info is None:
            return {
                "status": "error",
                "error": "ZimFileNotFound",
                "message": f"ZIM file not found: {zim_file}"
            }
        
        # Get additional stats
        cache_stats = zim_manager.get_cache_stats()
        
        return {
            "status": "success",
            "metadata": {
                "filename": file_info.filename,
                "title": file_info.title,
                "description": file_info.description,
                "size": file_info.size,
                "size_formatted": file_info.size_formatted,
                "article_count": file_info.article_count,
                "media_count": file_info.media_count,
                "language": file_info.language,
                "creator": file_info.creator,
                "date": file_info.date,
                "has_fulltext_index": file_info.has_fulltext_index,
                "has_title_index": file_info.has_title_index,
                "uuid": file_info.uuid
            },
            "cache_info": {
                "is_cached": file_info.filename in zim_manager.file_info_cache
            }
        }
        
    except Exception as e:
        logger.error(f"Error getting ZIM metadata for {zim_file}: {e}")
        return {
            "status": "error",
            "error": "ZimFileError",
            "message": f"Failed to get metadata: {str(e)}"
        }


@mcp.tool()
def read_zim_entry(zim_file: str, entry_path: str, format: str = "text") -> Dict[str, Any]:
    """
    Read specific entry content from a ZIM file.
    
    Args:
        zim_file: Name or path of the ZIM file
        entry_path: Path to the entry in the ZIM file
        format: Output format (text, html, raw)
    
    Returns:
        Dictionary containing entry content and metadata
    """
    try:
        logger.info(f"Reading entry {entry_path} from {zim_file}")
        
        # Validate format
        if format not in ["text", "html", "raw"]:
            return {
                "status": "error",
                "error": "InvalidFormat",
                "message": f"Invalid format: {format}. Must be one of: text, html, raw"
            }
        
        # Get entry
        entry = zim_manager.get_entry_by_path(zim_file, entry_path)
        
        if entry is None:
            return {
                "status": "error",
                "error": "EntryNotFound",
                "message": f"Entry not found: {entry_path} in {zim_file}"
            }
        
        # Get content
        item = entry.get_item()
        content_bytes = item.content
        
        # Convert content based on format
        if format == "raw":
            # Return raw bytes as base64 or hex
            content = content_bytes.hex()
        else:
            # Decode as text
            try:
                content = content_bytes.decode('utf-8')
            except UnicodeDecodeError:
                try:
                    content = content_bytes.decode('latin-1')
                except UnicodeDecodeError:
                    content = str(content_bytes)
            
            # Clean HTML if text format requested
            if format == "text" and content:
                from .utils import clean_html_content
                content = clean_html_content(content)
        
        # Truncate if too long
        if len(content) > config.max_content_length:
            content = content[:config.max_content_length] + "... [truncated]"
        
        return {
            "status": "success",
            "entry": {
                "path": entry.path,
                "title": entry.title,
                "content": content,
                "content_length": len(content_bytes),
                "format": format,
                "is_redirect": entry.is_redirect
            }
        }
        
    except Exception as e:
        logger.error(f"Error reading entry {entry_path} from {zim_file}: {e}")
        return {
            "status": "error",
            "error": "ZimFileError",
            "message": f"Failed to read entry: {str(e)}"
        }


@mcp.tool()
def search_zim_files(query: str, zim_files: Optional[List[str]] = None, 
                    max_results: int = 20, start_offset: int = 0) -> Dict[str, Any]:
    """
    Search for content across one or multiple ZIM files.
    
    Args:
        query: Search query string
        zim_files: Optional list of specific ZIM files to search (default: all)
        max_results: Maximum number of results (default: 20)
        start_offset: Pagination offset (default: 0)
    
    Returns:
        Dictionary containing search results with titles, paths, and relevance scores
    """
    try:
        logger.info(f"Searching ZIM files for: {query}")
        
        # Validate parameters
        if max_results <= 0 or max_results > config.max_search_results:
            return {
                "status": "error",
                "error": "InvalidMaxResults",
                "message": f"max_results must be between 1 and {config.max_search_results}"
            }
        
        if start_offset < 0:
            return {
                "status": "error",
                "error": "InvalidOffset",
                "message": "start_offset must be >= 0"
            }
        
        # Perform search
        if zim_files:
            # Search specific files
            results = search_engine.search_multiple_zim(zim_files, query, max_results, start_offset)
        else:
            # Search all files
            results = search_engine.search_all_zim_files(query, max_results, start_offset)
        
        # Format results
        formatted_results = []
        for result in results:
            formatted_results.append({
                "zim_file": result.zim_file,
                "path": result.path,
                "title": result.title,
                "score": result.score,
                "preview": result.preview,
                "is_redirect": result.is_redirect
            })
        
        return {
            "status": "success",
            "query": query,
            "count": len(formatted_results),
            "results": formatted_results,
            "pagination": {
                "start_offset": start_offset,
                "max_results": max_results,
                "has_more": len(results) == max_results
            }
        }
        
    except Exception as e:
        logger.error(f"Error searching ZIM files for '{query}': {e}")
        return {
            "status": "error",
            "error": "SearchError",
            "message": f"Search failed: {str(e)}"
        }


@mcp.tool()
def search_and_extract_content(query: str, zim_files: Optional[List[str]] = None,
                              max_results: int = 10, content_format: str = "text",
                              max_content_length: Optional[int] = None) -> Dict[str, Any]:
    """
    Search and return full content of matching entries.
    
    Args:
        query: Search query
        zim_files: Optional list of specific ZIM files
        max_results: Maximum results to extract content for
        content_format: Format for content (text, html)
        max_content_length: Maximum content length per entry
    
    Returns:
        Dictionary containing search results with full extracted content
    """
    try:
        logger.info(f"Searching and extracting content for: {query}")
        
        # Validate parameters
        if content_format not in ["text", "html"]:
            return {
                "status": "error",
                "error": "InvalidFormat",
                "message": "content_format must be 'text' or 'html'"
            }
        
        if max_results <= 0 or max_results > 50:
            return {
                "status": "error",
                "error": "InvalidMaxResults",
                "message": "max_results must be between 1 and 50"
            }
        
        # Perform search
        if zim_files:
            search_results = search_engine.search_multiple_zim(zim_files, query, max_results, 0)
        else:
            search_results = search_engine.search_all_zim_files(query, max_results, 0)
        
        # Extract content for each result
        extracted_contents = content_extractor.extract_search_results_content(
            search_results, content_format
        )
        
        # Format results
        formatted_results = []
        for content in extracted_contents:
            # Apply content length limit if specified
            content_text = content.content
            if max_content_length and len(content_text) > max_content_length:
                content_text = content_text[:max_content_length] + "... [truncated]"
            
            formatted_results.append({
                "path": content.path,
                "title": content.title,
                "content": content_text,
                "content_type": content.content_type,
                "content_length": content.content_length,
                "preview": content.preview,
                "is_redirect": content.is_redirect,
                "metadata": content.metadata
            })
        
        return {
            "status": "success",
            "query": query,
            "count": len(formatted_results),
            "results": formatted_results,
            "format": content_format
        }
        
    except Exception as e:
        logger.error(f"Error searching and extracting content for '{query}': {e}")
        return {
            "status": "error",
            "error": "SearchError",
            "message": f"Search and extraction failed: {str(e)}"
        }


@mcp.tool()
def browse_zim_entries(zim_file: str, path_pattern: Optional[str] = None,
                      title_pattern: Optional[str] = None, limit: int = 50) -> Dict[str, Any]:
    """
    Browse entries by path patterns or title patterns.
    
    Args:
        zim_file: ZIM file to browse
        path_pattern: Optional path pattern to match
        title_pattern: Optional title pattern to match
        limit: Maximum entries to return
    
    Returns:
        Dictionary containing list of matching entries with basic info
    """
    try:
        logger.info(f"Browsing entries in {zim_file}")
        
        # Validate parameters
        if limit <= 0 or limit > 200:
            return {
                "status": "error",
                "error": "InvalidLimit",
                "message": "limit must be between 1 and 200"
            }
        
        # Validate ZIM file
        if not zim_manager.validate_zim_file(zim_file):
            return {
                "status": "error",
                "error": "ZimFileNotFound",
                "message": f"ZIM file not found or not accessible: {zim_file}"
            }
        
        # Browse entries
        results = search_engine.browse_entries_by_pattern(
            zim_file, path_pattern, title_pattern, limit
        )
        
        # Format results
        formatted_results = []
        for result in results:
            formatted_results.append({
                "path": result.path,
                "title": result.title,
                "is_redirect": result.is_redirect
            })
        
        return {
            "status": "success",
            "zim_file": zim_file,
            "path_pattern": path_pattern,
            "title_pattern": title_pattern,
            "count": len(formatted_results),
            "entries": formatted_results
        }
        
    except Exception as e:
        logger.error(f"Error browsing entries in {zim_file}: {e}")
        return {
            "status": "error",
            "error": "BrowseError",
            "message": f"Browse failed: {str(e)}"
        }

@mcp.tool()
def get_random_entries(zim_files: Optional[List[str]] = None, count: int = 5) -> Dict[str, Any]:
    """
    Get random entries from ZIM files for exploration.
    
    Args:
        zim_files: Optional list of specific ZIM files (default: all available)
        count: Number of random entries to return
    
    Returns:
        Dictionary containing random entries with basic info
    """
    try:
        logger.info(f"Getting {count} random entries")
        
        # Validate count
        if count <= 0 or count > 50:
            return {
                "status": "error",
                "error": "InvalidCount",
                "message": "Count must be between 1 and 50"
            }
        
        # Get available files if none specified
        if zim_files is None:
            available_files = zim_manager.discover_zim_files()
            zim_files = [f.filename for f in available_files]
        
        if not zim_files:
            return {
                "status": "error",
                "error": "NoZimFiles",
                "message": "No ZIM files available"
            }
        
        random_entries = []
        entries_per_file = max(1, count // len(zim_files))
        
        for zim_file in zim_files:
            try:
                for _ in range(entries_per_file):
                    if len(random_entries) >= count:
                        break
                    
                    entry = zim_manager.get_random_entry(zim_file)
                    if entry:
                        random_entries.append({
                            "zim_file": zim_file,
                            "path": entry.path,
                            "title": entry.title,
                            "is_redirect": entry.is_redirect
                        })
            except Exception as e:
                logger.warning(f"Error getting random entry from {zim_file}: {e}")
                continue
        
        return {
            "status": "success",
            "count": len(random_entries),
            "entries": random_entries
        }
        
    except Exception as e:
        logger.error(f"Error getting random entries: {e}")
        return {
            "status": "error",
            "error": "ZimFileError",
            "message": f"Failed to get random entries: {str(e)}"
        }


# Resource endpoints
@mcp.resource("zim://files")
def list_zim_files_resource() -> str:
    """Provide list of available ZIM files as a resource"""
    try:
        result = list_zim_files()
        if result["status"] == "success":
            import json
            return json.dumps(result["files"], indent=2)
        else:
            return f"Error: {result.get('message', 'Unknown error')}"
    except Exception as e:
        return f"Error: {str(e)}"


@mcp.resource("zim://file/{filename}/metadata")
def get_zim_metadata_resource(filename: str) -> str:
    """Provide ZIM file metadata as a resource"""
    try:
        result = get_zim_metadata(filename)
        if result["status"] == "success":
            import json
            return json.dumps(result["metadata"], indent=2)
        else:
            return f"Error: {result.get('message', 'Unknown error')}"
    except Exception as e:
        return f"Error: {str(e)}"


@mcp.resource("zim://file/{filename}/entry/{path}")
def read_zim_entry_resource(filename: str, path: str) -> str:
    """Provide specific entry content as a resource"""
    try:
        result = read_zim_entry(filename, path, "text")
        if result["status"] == "success":
            return result["entry"]["content"]
        else:
            return f"Error: {result.get('message', 'Unknown error')}"
    except Exception as e:
        return f"Error: {str(e)}"


def main():
    """Main entry point for the server"""
    import argparse
    
    parser = argparse.ArgumentParser(description="MCP ZIM Server")
    parser.add_argument("--transport", choices=["stdio", "sse"], default="stdio",
                       help="Transport type (default: stdio)")
    parser.add_argument("--port", type=int, default=8000,
                       help="Port for SSE transport (default: 8000)")
    
    args = parser.parse_args()
    
    logger.info(f"Starting MCP ZIM Server with {args.transport} transport")
    logger.info(f"ZIM files directory: {config.zim_files_directory}")
    
    # Discover ZIM files on startup
    zim_files = zim_manager.discover_zim_files()
    logger.info(f"Found {len(zim_files)} ZIM files")
    
    if args.transport == "stdio":
        # Run with stdio transport
        mcp.run()
    else:
        # Run with SSE transport
        mcp.run_sse(port=args.port)


if __name__ == "__main__":
    main()

