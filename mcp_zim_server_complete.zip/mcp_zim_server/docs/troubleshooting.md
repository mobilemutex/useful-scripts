# MCP ZIM Server - Troubleshooting Guide

This guide provides solutions to common problems you might encounter while using the MCP ZIM Server.

## Problem: No ZIM files are found

**Symptom:** The `list_zim_files` tool returns an empty list, or the server logs show "Discovered 0 ZIM files".

**Solution:**

1.  **Check the ZIM files directory:** Ensure that your ZIM files are located in the correct directory. By default, this is the `./zim_files` directory relative to where you run the server. You can specify a different directory using the `ZIM_FILES_DIRECTORY` environment variable.

2.  **Verify file permissions:** Make sure the server has read permissions for the ZIM files and the directory they are in.

3.  **Check file extensions:** The server only discovers files with the `.zim` extension. Ensure your files are named correctly.

## Problem: Search returns no results

**Symptom:** The `search_zim_files` tool returns no results, even for queries you expect to have matches.

**Solution:**

1.  **Check for a full-text index:** The ZIM file you are searching must have a full-text index. You can verify this by checking the `has_fulltext_index` field in the output of the `get_zim_metadata` tool. If it is `false`, you cannot search that file.

2.  **Try a broader query:** Your query might be too specific. Try a more general query to see if you get any results.

3.  **Check the ZIM file content:** The content you are searching for might not be in the ZIM file. You can use the `browse_zim_entries` tool to explore the content of the file.

## Problem: Server fails to start

**Symptom:** The server exits with an error message when you try to run it.

**Solution:**

1.  **Check for conflicting processes:** Make sure that no other process is using the port you are trying to use for the SSE transport.

2.  **Check your Python environment:** Ensure that you have installed all the required dependencies. You can do this by running `pip install -r requirements.txt`.

3.  **Check the logs:** The server logs will often provide a detailed error message that can help you diagnose the problem.

## Problem: Errors when reading or searching

**Symptom:** You receive errors like `ZimFileNotFound`, `EntryNotFound`, or `SearchError`.

**Solution:**

1.  **Verify file and entry names:** Double-check that you are using the correct file names and entry paths. Remember that they are case-sensitive.

2.  **Check for corrupted files:** The ZIM file might be corrupted. Try opening it with another ZIM reader to see if it is valid.

3.  **Consult the logs:** The server logs will provide more details about the error. This can be helpful for debugging.

If you are still having problems, please open an issue on the project's GitHub repository with a detailed description of the problem and the steps you have taken to troubleshoot it.


