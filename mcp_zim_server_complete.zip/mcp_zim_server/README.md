# MCP ZIM Server

**Author**: mobilemutex

An MCP (Model Context Protocol) server that provides offline search and content extraction capabilities for Large Language Models (LLMs) using ZIM files. This server allows LLMs to perform deep research and access vast amounts of information in offline environments, effectively replacing the need for live web access.

## Features

- **Offline Search**: Full-text search across millions of articles within ZIM files.
- **Content Extraction**: Extract and format content from ZIM entries in various formats (text, HTML).
- **ZIM File Management**: Automatically discover and manage ZIM files in a specified directory.
- **Comprehensive Toolset**: A rich set of tools for listing files, getting metadata, searching, reading, and browsing content.
- **Resource Endpoints**: MCP resource endpoints for seamless integration with LLM clients.
- **Caching**: In-memory caching for archives, search results, and file info to improve performance.
- **Configurable**: Easily configurable through environment variables.
- **Error Handling**: Robust error handling to provide clear feedback to the LLM.

## Requirements

- Python 3.8+
- `pip` for package installation

## Installation

1.  **Clone the repository or download the source code:**

    ```bash
    git clone https://github.com/your-repo/mcp-zim-server.git
    cd mcp-zim-server
    ```

2.  **Install the required dependencies:**

    ```bash
    pip install -r requirements.txt
    ```

    *(Note: A `requirements.txt` file would be created for a production release. For now, the dependencies are `mcp[cli]` and `libzim`)*

## Configuration

The server can be configured using the following environment variables:

-   `ZIM_FILES_DIRECTORY`: The directory where your ZIM files are stored. (Default: `./zim_files`)
-   `MAX_SEARCH_RESULTS`: The maximum number of search results to return per query. (Default: `100`)
-   `SEARCH_TIMEOUT`: The timeout for search operations in seconds. (Default: `30`)
-   `LOG_LEVEL`: The logging level for the server. (Default: `INFO`)

## Usage

1.  **Place your ZIM files** in the directory specified by the `ZIM_FILES_DIRECTORY` environment variable (or the default `./zim_files` directory).

2.  **Run the server** using one of the supported transports:

    -   **Standard I/O (stdio):**

        ```bash
        python -m mcp_zim_server --transport stdio
        ```

    -   **Server-Sent Events (SSE):**

        ```bash
        python -m mcp_zim_server --transport sse --port 8000
        ```

## Available Tools

Here is a detailed description of the tools exposed by the MCP ZIM Server:

### `list_zim_files()`

Lists all available ZIM files in the configured directory.

-   **Parameters**: None
-   **Returns**: A dictionary containing a list of ZIM files with their metadata.

### `get_zim_metadata(zim_file: str)`

Gets detailed metadata about a specific ZIM file.

-   **Parameters**:
    -   `zim_file` (str): The name of the ZIM file.
-   **Returns**: A dictionary containing detailed metadata for the specified ZIM file.

### `search_zim_files(query: str, zim_files: Optional[List[str]], max_results: int, start_offset: int)`

Searches for content across one or multiple ZIM files.

-   **Parameters**:
    -   `query` (str): The search query.
    -   `zim_files` (Optional[List[str]]): A list of ZIM files to search. If not provided, all files are searched.
    -   `max_results` (int): The maximum number of results to return. (Default: 20)
    -   `start_offset` (int): The pagination offset. (Default: 0)
-   **Returns**: A dictionary containing the search results.

### `read_zim_entry(zim_file: str, entry_path: str, format: str)`

Reads the content of a specific entry from a ZIM file.

-   **Parameters**:
    -   `zim_file` (str): The name of the ZIM file.
    -   `entry_path` (str): The path to the entry.
    -   `format` (str): The output format (`text`, `html`, `raw`). (Default: `text`)
-   **Returns**: A dictionary containing the entry's content.

### `search_and_extract_content(query: str, ...)`

Performs a search and returns the full content of the matching entries.

-   **Parameters**: Similar to `search_zim_files`, with additional content formatting options.
-   **Returns**: A dictionary containing the search results with their full content.

### `browse_zim_entries(zim_file: str, ...)`

Browses entries by path or title patterns.

-   **Parameters**:
    -   `zim_file` (str): The ZIM file to browse.
    -   `path_pattern` (Optional[str]): A pattern to match against entry paths.
    -   `title_pattern` (Optional[str]): A pattern to match against entry titles.
    -   `limit` (int): The maximum number of entries to return.
-   **Returns**: A list of matching entries.

### `get_random_entries(zim_files: Optional[List[str]], count: int)`

Gets a specified number of random entries from ZIM files.

-   **Parameters**:
    -   `zim_files` (Optional[List[str]]): A list of ZIM files to get entries from.
    -   `count` (int): The number of random entries to return.
-   **Returns**: A list of random entries.

## Resource Endpoints

The server also exposes the following resource endpoints:

-   `zim://files`: Lists all available ZIM files.
-   `zim://file/{filename}/metadata`: Provides metadata for a specific ZIM file.
-   `zim://file/{filename}/entry/{path}`: Provides the content of a specific entry.

## Error Handling

The server provides detailed error messages in a structured format to help the LLM understand and recover from errors. Common error types include `ZimFileNotFound`, `EntryNotFound`, and `SearchError`.

## Development

Contributions are welcome! If you want to contribute to the development of the MCP ZIM Server, please follow these steps:

1.  Fork the repository.
2.  Create a new branch for your feature or bug fix.
3.  Make your changes and write tests.
4.  Submit a pull request.

## License

This project is licensed under the MIT License. See the `LICENSE` file for details.


