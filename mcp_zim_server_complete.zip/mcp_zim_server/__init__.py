"""
MCP ZIM Server - Offline search capabilities for LLMs using ZIM files

Author: mobilemutex
"""

__version__ = "1.0.0"
__author__ = "mobilemutex"
__description__ = "MCP server providing offline search capabilities through ZIM files"

