#!/usr/bin/env python3
"""
Test script for MCP ZIM Server

Author: mobilemutex
"""

import sys
import os
sys.path.insert(0, '/home/ubuntu')

from mcp_zim_server.server import (
    list_zim_files, get_zim_metadata, read_zim_entry,
    search_zim_files, search_and_extract_content,
    browse_zim_entries, get_random_entries
)


def test_list_zim_files():
    """Test list_zim_files tool"""
    print("Testing list_zim_files...")
    result = list_zim_files()
    print(f"Result: {result}")
    assert result["status"] == "success"
    assert "count" in result
    assert "files" in result
    print("✓ list_zim_files test passed")


def test_get_zim_metadata():
    """Test get_zim_metadata tool with non-existent file"""
    print("Testing get_zim_metadata with non-existent file...")
    result = get_zim_metadata("nonexistent.zim")
    print(f"Result: {result}")
    assert result["status"] == "error"
    assert result["error"] == "ZimFileNotFound"
    print("✓ get_zim_metadata test passed")


def test_read_zim_entry():
    """Test read_zim_entry tool with non-existent file"""
    print("Testing read_zim_entry with non-existent file...")
    result = read_zim_entry("nonexistent.zim", "/test/path")
    print(f"Result: {result}")
    assert result["status"] == "error"
    print("✓ read_zim_entry test passed")


def test_search_zim_files():
    """Test search_zim_files tool"""
    print("Testing search_zim_files...")
    result = search_zim_files("test query")
    print(f"Result: {result}")
    assert result["status"] == "success"
    assert "query" in result
    assert "count" in result
    assert "results" in result
    print("✓ search_zim_files test passed")


def test_search_and_extract_content():
    """Test search_and_extract_content tool"""
    print("Testing search_and_extract_content...")
    result = search_and_extract_content("test query")
    print(f"Result: {result}")
    assert result["status"] == "success"
    assert "query" in result
    assert "count" in result
    assert "results" in result
    print("✓ search_and_extract_content test passed")


def test_browse_zim_entries():
    """Test browse_zim_entries tool with non-existent file"""
    print("Testing browse_zim_entries with non-existent file...")
    result = browse_zim_entries("nonexistent.zim")
    print(f"Result: {result}")
    assert result["status"] == "error"
    assert result["error"] == "ZimFileNotFound"
    print("✓ browse_zim_entries test passed")


def test_get_random_entries():
    """Test get_random_entries tool"""
    print("Testing get_random_entries...")
    result = get_random_entries()
    print(f"Result: {result}")
    assert result["status"] == "error"  # Should error with no ZIM files
    assert result["error"] == "NoZimFiles"
    print("✓ get_random_entries test passed")


def test_parameter_validation():
    """Test parameter validation"""
    print("Testing parameter validation...")
    
    # Test invalid max_results
    result = search_zim_files("test", max_results=1000)
    assert result["status"] == "error"
    assert result["error"] == "InvalidMaxResults"
    
    # Test invalid offset
    result = search_zim_files("test", start_offset=-1)
    assert result["status"] == "error"
    assert result["error"] == "InvalidOffset"
    
    # Test invalid format
    result = search_and_extract_content("test", content_format="invalid")
    assert result["status"] == "error"
    assert result["error"] == "InvalidFormat"
    
    # Test invalid count
    result = get_random_entries(count=100)
    assert result["status"] == "error"
    assert result["error"] == "InvalidCount"
    
    print("✓ Parameter validation tests passed")


def main():
    """Run all tests"""
    print("Starting MCP ZIM Server tests...")
    print("=" * 50)
    
    try:
        test_list_zim_files()
        test_get_zim_metadata()
        test_read_zim_entry()
        test_search_zim_files()
        test_search_and_extract_content()
        test_browse_zim_entries()
        test_get_random_entries()
        test_parameter_validation()
        
        print("=" * 50)
        print("✅ All tests passed!")
        print("MCP ZIM Server is working correctly.")
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()

